﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class IlacSil : Form
    {
        public IlacSil()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        private void IlacSil_Load(object sender, EventArgs e)
        {

        }

        private void btnIlacSilBul_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand IlacSil = new NpgsqlCommand();
            IlacSil.Connection = conn;
            IlacSil.Parameters.AddWithValue("@IlacBarkodNo", Convert.ToDouble(textBoxIlacSil.Text));
            IlacSil.CommandType = CommandType.Text;
            IlacSil.CommandText = "SELECT * FROM \"Ilaclar\" WHERE \"IlacBarkodNo\" = @IlacBarkodNo";
            NpgsqlDataReader dr = IlacSil.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewIlacSil.DataSource = dt;
            }

            IlacSil.Dispose();
            conn.Close();
        }

        private void btnIlacSil_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand IlacSil = new NpgsqlCommand();
            IlacSil.Connection = conn;
            IlacSil.Parameters.AddWithValue("@IlacBarkodNo", Convert.ToDouble(textBoxIlacSil.Text));
            IlacSil.CommandType = CommandType.Text;
            IlacSil.CommandText = "DELETE FROM \"Ilaclar\" WHERE \"IlacBarkodNo\" = @IlacBarkodNo";
            NpgsqlDataReader dr = IlacSil.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewIlacSil.DataSource = dt;
            }

            IlacSil.Dispose();
            conn.Close();
            textBoxIlacSil.Clear();
            dataGridViewIlacSil.Columns.Clear();
            MessageBox.Show("Seçtiğiniz ilaç başarılı bir şekilde sistemden silinmiştir.", "İLAÇ SİLİNDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Hide();
            IlacListesi IL = new IlacListesi();
            IL.Show();
        }

        private void btnIlacSilIptal_Click(object sender, EventArgs e)
        {
            this.Hide();
            IlacListesi IL = new IlacListesi();
            IL.Show();
        }

        private void btnIlacSilAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
