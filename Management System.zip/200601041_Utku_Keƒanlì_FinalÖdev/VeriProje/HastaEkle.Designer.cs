﻿namespace VeriProje
{
    partial class HastaEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxHastaTC = new System.Windows.Forms.TextBox();
            this.textBoxHastaIsim = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxHastaDogumYeri = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxHastaAdresi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxHastaTelNO = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxHastaMedeniDurum = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxHastaDogumGunu = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnHastaEkleAnaSayfa = new System.Windows.Forms.Button();
            this.btnHastaEkleIptal = new System.Windows.Forms.Button();
            this.btnHastaEkle = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hastanın TC\'si";
            // 
            // textBoxHastaTC
            // 
            this.textBoxHastaTC.Location = new System.Drawing.Point(243, 63);
            this.textBoxHastaTC.Name = "textBoxHastaTC";
            this.textBoxHastaTC.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaTC.TabIndex = 1;
            // 
            // textBoxHastaIsim
            // 
            this.textBoxHastaIsim.Location = new System.Drawing.Point(243, 98);
            this.textBoxHastaIsim.Name = "textBoxHastaIsim";
            this.textBoxHastaIsim.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaIsim.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Hastanın İsmi ve Soyismi";
            // 
            // textBoxHastaDogumYeri
            // 
            this.textBoxHastaDogumYeri.Location = new System.Drawing.Point(243, 135);
            this.textBoxHastaDogumYeri.Name = "textBoxHastaDogumYeri";
            this.textBoxHastaDogumYeri.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaDogumYeri.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Hastanın Doğum Yeri";
            // 
            // textBoxHastaAdresi
            // 
            this.textBoxHastaAdresi.Location = new System.Drawing.Point(243, 171);
            this.textBoxHastaAdresi.Name = "textBoxHastaAdresi";
            this.textBoxHastaAdresi.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaAdresi.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Hastanın Adresi";
            // 
            // textBoxHastaTelNO
            // 
            this.textBoxHastaTelNO.Location = new System.Drawing.Point(243, 208);
            this.textBoxHastaTelNO.Name = "textBoxHastaTelNO";
            this.textBoxHastaTelNO.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaTelNO.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(64, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Hastanın Telefon Numarası";
            // 
            // textBoxHastaMedeniDurum
            // 
            this.textBoxHastaMedeniDurum.Location = new System.Drawing.Point(243, 245);
            this.textBoxHastaMedeniDurum.Name = "textBoxHastaMedeniDurum";
            this.textBoxHastaMedeniDurum.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaMedeniDurum.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(64, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Hastanın Medeni Durumu";
            // 
            // textBoxHastaDogumGunu
            // 
            this.textBoxHastaDogumGunu.Location = new System.Drawing.Point(243, 283);
            this.textBoxHastaDogumGunu.Name = "textBoxHastaDogumGunu";
            this.textBoxHastaDogumGunu.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaDogumGunu.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(64, 283);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Hastanın Doğum Günü";
            // 
            // btnHastaEkleAnaSayfa
            // 
            this.btnHastaEkleAnaSayfa.Location = new System.Drawing.Point(462, 237);
            this.btnHastaEkleAnaSayfa.Name = "btnHastaEkleAnaSayfa";
            this.btnHastaEkleAnaSayfa.Size = new System.Drawing.Size(145, 62);
            this.btnHastaEkleAnaSayfa.TabIndex = 16;
            this.btnHastaEkleAnaSayfa.Text = "ANA SAYFAYA DÖN";
            this.btnHastaEkleAnaSayfa.UseVisualStyleBackColor = true;
            this.btnHastaEkleAnaSayfa.Click += new System.EventHandler(this.btnHastaEkleAnaSayfa_Click);
            // 
            // btnHastaEkleIptal
            // 
            this.btnHastaEkleIptal.Location = new System.Drawing.Point(462, 149);
            this.btnHastaEkleIptal.Name = "btnHastaEkleIptal";
            this.btnHastaEkleIptal.Size = new System.Drawing.Size(145, 62);
            this.btnHastaEkleIptal.TabIndex = 15;
            this.btnHastaEkleIptal.Text = "İPTAL";
            this.btnHastaEkleIptal.UseVisualStyleBackColor = true;
            this.btnHastaEkleIptal.Click += new System.EventHandler(this.btnHastaEkleIptal_Click);
            // 
            // btnHastaEkle
            // 
            this.btnHastaEkle.Location = new System.Drawing.Point(462, 64);
            this.btnHastaEkle.Name = "btnHastaEkle";
            this.btnHastaEkle.Size = new System.Drawing.Size(145, 62);
            this.btnHastaEkle.TabIndex = 14;
            this.btnHastaEkle.Text = "YENİ BİR HASTA EKLE";
            this.btnHastaEkle.UseVisualStyleBackColor = true;
            this.btnHastaEkle.Click += new System.EventHandler(this.btnHastaEkle_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(30, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(622, 310);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "HASTA EKLE";
            // 
            // HastaEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(686, 366);
            this.Controls.Add(this.btnHastaEkleAnaSayfa);
            this.Controls.Add(this.btnHastaEkleIptal);
            this.Controls.Add(this.btnHastaEkle);
            this.Controls.Add(this.textBoxHastaDogumGunu);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxHastaMedeniDurum);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxHastaTelNO);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxHastaAdresi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxHastaDogumYeri);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxHastaIsim);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxHastaTC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "HastaEkle";
            this.Text = "HastaEkle";
            this.Load += new System.EventHandler(this.HastaEkle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxHastaTC;
        private System.Windows.Forms.TextBox textBoxHastaIsim;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxHastaDogumYeri;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxHastaAdresi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxHastaTelNO;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxHastaMedeniDurum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxHastaDogumGunu;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnHastaEkleAnaSayfa;
        private System.Windows.Forms.Button btnHastaEkleIptal;
        private System.Windows.Forms.Button btnHastaEkle;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}