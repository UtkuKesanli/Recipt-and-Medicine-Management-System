﻿namespace VeriProje
{
    partial class ReceteListesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnReceteListeAnaSayfa = new System.Windows.Forms.Button();
            this.dataGridViewReceteListe = new System.Windows.Forms.DataGridView();
            this.btnReceteListeBul = new System.Windows.Forms.Button();
            this.btnReceteEkle = new System.Windows.Forms.Button();
            this.textBoxReceteBul = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReceteListe)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnReceteListeAnaSayfa);
            this.groupBox1.Controls.Add(this.dataGridViewReceteListe);
            this.groupBox1.Controls.Add(this.btnReceteListeBul);
            this.groupBox1.Controls.Add(this.btnReceteEkle);
            this.groupBox1.Controls.Add(this.textBoxReceteBul);
            this.groupBox1.Location = new System.Drawing.Point(23, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(701, 386);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "REÇETELER";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 324);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Hastanın TC\'si";
            // 
            // btnReceteListeAnaSayfa
            // 
            this.btnReceteListeAnaSayfa.Location = new System.Drawing.Point(526, 308);
            this.btnReceteListeAnaSayfa.Name = "btnReceteListeAnaSayfa";
            this.btnReceteListeAnaSayfa.Size = new System.Drawing.Size(145, 44);
            this.btnReceteListeAnaSayfa.TabIndex = 18;
            this.btnReceteListeAnaSayfa.Text = "ANA SAYAFAYA DÖN";
            this.btnReceteListeAnaSayfa.UseVisualStyleBackColor = true;
            this.btnReceteListeAnaSayfa.Click += new System.EventHandler(this.btnReceteListeAnaSayfa_Click);
            // 
            // dataGridViewReceteListe
            // 
            this.dataGridViewReceteListe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewReceteListe.Location = new System.Drawing.Point(26, 34);
            this.dataGridViewReceteListe.Name = "dataGridViewReceteListe";
            this.dataGridViewReceteListe.Size = new System.Drawing.Size(645, 247);
            this.dataGridViewReceteListe.TabIndex = 20;
            // 
            // btnReceteListeBul
            // 
            this.btnReceteListeBul.Location = new System.Drawing.Point(262, 314);
            this.btnReceteListeBul.Name = "btnReceteListeBul";
            this.btnReceteListeBul.Size = new System.Drawing.Size(91, 33);
            this.btnReceteListeBul.TabIndex = 21;
            this.btnReceteListeBul.Text = "HASTAYI BUL";
            this.btnReceteListeBul.UseVisualStyleBackColor = true;
            this.btnReceteListeBul.Click += new System.EventHandler(this.btnReceteListeBul_Click);
            // 
            // btnReceteEkle
            // 
            this.btnReceteEkle.Location = new System.Drawing.Point(375, 309);
            this.btnReceteEkle.Name = "btnReceteEkle";
            this.btnReceteEkle.Size = new System.Drawing.Size(145, 43);
            this.btnReceteEkle.TabIndex = 16;
            this.btnReceteEkle.Text = "YENİ BİR REÇETE EKLE";
            this.btnReceteEkle.UseVisualStyleBackColor = true;
            this.btnReceteEkle.Click += new System.EventHandler(this.btnReceteEkle_Click);
            // 
            // textBoxReceteBul
            // 
            this.textBoxReceteBul.Location = new System.Drawing.Point(113, 321);
            this.textBoxReceteBul.Name = "textBoxReceteBul";
            this.textBoxReceteBul.Size = new System.Drawing.Size(134, 20);
            this.textBoxReceteBul.TabIndex = 15;
            // 
            // ReceteListesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 440);
            this.Controls.Add(this.groupBox1);
            this.Name = "ReceteListesi";
            this.Text = "Recete";
            this.Load += new System.EventHandler(this.ReceteListesi_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReceteListe)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnReceteListeAnaSayfa;
        private System.Windows.Forms.DataGridView dataGridViewReceteListe;
        private System.Windows.Forms.Button btnReceteListeBul;
        private System.Windows.Forms.Button btnReceteEkle;
        private System.Windows.Forms.TextBox textBoxReceteBul;
        private System.Windows.Forms.Label label2;
    }
}