﻿namespace VeriProje
{
    partial class HastaSil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxHastaSil = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHaslaSilAnaSayfa = new System.Windows.Forms.Button();
            this.btnHastaSilIptal = new System.Windows.Forms.Button();
            this.btnHastaSil = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridViewHastaSil = new System.Windows.Forms.DataGridView();
            this.btnHastaSilBul = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHastaSil)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxHastaSil
            // 
            this.textBoxHastaSil.Location = new System.Drawing.Point(324, 183);
            this.textBoxHastaSil.Name = "textBoxHastaSil";
            this.textBoxHastaSil.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaSil.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(224, 186);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Hastanın TC\'si";
            // 
            // btnHaslaSilAnaSayfa
            // 
            this.btnHaslaSilAnaSayfa.Location = new System.Drawing.Point(520, 228);
            this.btnHaslaSilAnaSayfa.Name = "btnHaslaSilAnaSayfa";
            this.btnHaslaSilAnaSayfa.Size = new System.Drawing.Size(145, 62);
            this.btnHaslaSilAnaSayfa.TabIndex = 10;
            this.btnHaslaSilAnaSayfa.Text = "ANA SAYAFAYA DÖN";
            this.btnHaslaSilAnaSayfa.UseVisualStyleBackColor = true;
            this.btnHaslaSilAnaSayfa.Click += new System.EventHandler(this.btnHaslaSilAnaSayfa_Click);
            // 
            // btnHastaSilIptal
            // 
            this.btnHastaSilIptal.Location = new System.Drawing.Point(347, 228);
            this.btnHastaSilIptal.Name = "btnHastaSilIptal";
            this.btnHastaSilIptal.Size = new System.Drawing.Size(145, 62);
            this.btnHastaSilIptal.TabIndex = 9;
            this.btnHastaSilIptal.Text = "İPTAL";
            this.btnHastaSilIptal.UseVisualStyleBackColor = true;
            this.btnHastaSilIptal.Click += new System.EventHandler(this.btnHastaSilIptal_Click);
            // 
            // btnHastaSil
            // 
            this.btnHastaSil.Location = new System.Drawing.Point(175, 228);
            this.btnHastaSil.Name = "btnHastaSil";
            this.btnHastaSil.Size = new System.Drawing.Size(145, 62);
            this.btnHastaSil.TabIndex = 8;
            this.btnHastaSil.Text = "HASTANIN KAYDINI SİL";
            this.btnHastaSil.UseVisualStyleBackColor = true;
            this.btnHastaSil.Click += new System.EventHandler(this.btnHastaSil_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(26, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(809, 306);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "HASTA SİL";
            // 
            // dataGridViewHastaSil
            // 
            this.dataGridViewHastaSil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHastaSil.Location = new System.Drawing.Point(54, 69);
            this.dataGridViewHastaSil.Name = "dataGridViewHastaSil";
            this.dataGridViewHastaSil.Size = new System.Drawing.Size(749, 69);
            this.dataGridViewHastaSil.TabIndex = 12;
            // 
            // btnHastaSilBul
            // 
            this.btnHastaSilBul.Location = new System.Drawing.Point(537, 176);
            this.btnHastaSilBul.Name = "btnHastaSilBul";
            this.btnHastaSilBul.Size = new System.Drawing.Size(91, 33);
            this.btnHastaSilBul.TabIndex = 13;
            this.btnHastaSilBul.Text = "HASTAYI BUL";
            this.btnHastaSilBul.UseVisualStyleBackColor = true;
            this.btnHastaSilBul.Click += new System.EventHandler(this.btnHastaSilBul_Click);
            // 
            // HastaSil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(867, 362);
            this.Controls.Add(this.btnHastaSilBul);
            this.Controls.Add(this.dataGridViewHastaSil);
            this.Controls.Add(this.btnHaslaSilAnaSayfa);
            this.Controls.Add(this.btnHastaSilIptal);
            this.Controls.Add(this.btnHastaSil);
            this.Controls.Add(this.textBoxHastaSil);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "HastaSil";
            this.Text = "HastaSil";
            this.Load += new System.EventHandler(this.HastaSil_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHastaSil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxHastaSil;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnHaslaSilAnaSayfa;
        private System.Windows.Forms.Button btnHastaSilIptal;
        private System.Windows.Forms.Button btnHastaSil;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridViewHastaSil;
        private System.Windows.Forms.Button btnHastaSilBul;
    }
}