﻿namespace VeriProje
{
    partial class HastaListesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewHastaListesi = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnBirHastaSil = new System.Windows.Forms.Button();
            this.btnYeniHastaEkle = new System.Windows.Forms.Button();
            this.btnHaslaListeAnaSayfa = new System.Windows.Forms.Button();
            this.btnBirHastaGuncelle = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHastaListesi)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewHastaListesi
            // 
            this.dataGridViewHastaListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHastaListesi.Location = new System.Drawing.Point(21, 28);
            this.dataGridViewHastaListesi.Name = "dataGridViewHastaListesi";
            this.dataGridViewHastaListesi.Size = new System.Drawing.Size(759, 236);
            this.dataGridViewHastaListesi.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnHaslaListeAnaSayfa);
            this.groupBox1.Controls.Add(this.btnBirHastaGuncelle);
            this.groupBox1.Controls.Add(this.btnBirHastaSil);
            this.groupBox1.Controls.Add(this.btnYeniHastaEkle);
            this.groupBox1.Controls.Add(this.dataGridViewHastaListesi);
            this.groupBox1.Location = new System.Drawing.Point(25, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(801, 379);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "HASTALARIN LİSTESİ";
            // 
            // btnBirHastaSil
            // 
            this.btnBirHastaSil.Location = new System.Drawing.Point(238, 292);
            this.btnBirHastaSil.Name = "btnBirHastaSil";
            this.btnBirHastaSil.Size = new System.Drawing.Size(145, 62);
            this.btnBirHastaSil.TabIndex = 5;
            this.btnBirHastaSil.Text = "BİR HASTANIN KAYDINI SİL";
            this.btnBirHastaSil.UseVisualStyleBackColor = true;
            this.btnBirHastaSil.Click += new System.EventHandler(this.btnBirHastaSil_Click);
            // 
            // btnYeniHastaEkle
            // 
            this.btnYeniHastaEkle.Location = new System.Drawing.Point(65, 292);
            this.btnYeniHastaEkle.Name = "btnYeniHastaEkle";
            this.btnYeniHastaEkle.Size = new System.Drawing.Size(145, 62);
            this.btnYeniHastaEkle.TabIndex = 4;
            this.btnYeniHastaEkle.Text = "YENİ BİR HASTA EKLE";
            this.btnYeniHastaEkle.UseVisualStyleBackColor = true;
            this.btnYeniHastaEkle.Click += new System.EventHandler(this.btnYeniHastaEkle_Click);
            // 
            // btnHaslaListeAnaSayfa
            // 
            this.btnHaslaListeAnaSayfa.Location = new System.Drawing.Point(583, 292);
            this.btnHaslaListeAnaSayfa.Name = "btnHaslaListeAnaSayfa";
            this.btnHaslaListeAnaSayfa.Size = new System.Drawing.Size(145, 62);
            this.btnHaslaListeAnaSayfa.TabIndex = 7;
            this.btnHaslaListeAnaSayfa.Text = "ANA SAYAFAYA DÖN";
            this.btnHaslaListeAnaSayfa.UseVisualStyleBackColor = true;
            this.btnHaslaListeAnaSayfa.Click += new System.EventHandler(this.btnHaslaListeAnaSayfa_Click);
            // 
            // btnBirHastaGuncelle
            // 
            this.btnBirHastaGuncelle.Location = new System.Drawing.Point(410, 292);
            this.btnBirHastaGuncelle.Name = "btnBirHastaGuncelle";
            this.btnBirHastaGuncelle.Size = new System.Drawing.Size(145, 62);
            this.btnBirHastaGuncelle.TabIndex = 6;
            this.btnBirHastaGuncelle.Text = "BİR HASTANIN KAYDINI GÜNCELLE";
            this.btnBirHastaGuncelle.UseVisualStyleBackColor = true;
            this.btnBirHastaGuncelle.Click += new System.EventHandler(this.btnBirHastaGuncelle_Click);
            // 
            // HastaListesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(856, 437);
            this.Controls.Add(this.groupBox1);
            this.Name = "HastaListesi";
            this.Text = "HastaListesi";
            this.Load += new System.EventHandler(this.HastaListesi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHastaListesi)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewHastaListesi;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnHaslaListeAnaSayfa;
        private System.Windows.Forms.Button btnBirHastaGuncelle;
        private System.Windows.Forms.Button btnBirHastaSil;
        private System.Windows.Forms.Button btnYeniHastaEkle;
    }
}