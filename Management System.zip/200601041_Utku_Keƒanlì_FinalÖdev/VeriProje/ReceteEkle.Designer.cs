﻿namespace VeriProje
{
    partial class ReceteEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHastaReceteBul = new System.Windows.Forms.Button();
            this.dataGridViewReceteEkle = new System.Windows.Forms.DataGridView();
            this.textBoxReceteBul = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnReceteEkleAnaSayfa = new System.Windows.Forms.Button();
            this.btnReceteEkleIptal = new System.Windows.Forms.Button();
            this.textBoxHastaReceteNo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxHastaTedavi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxHastaTani = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxHastaSikayet = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxMuayeneTarihi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnReceteEkleVeriGuncelle = new System.Windows.Forms.Button();
            this.btnYeniReceteEkle = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReceteEkle)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnHastaReceteBul
            // 
            this.btnHastaReceteBul.Location = new System.Drawing.Point(422, 164);
            this.btnHastaReceteBul.Name = "btnHastaReceteBul";
            this.btnHastaReceteBul.Size = new System.Drawing.Size(91, 33);
            this.btnHastaReceteBul.TabIndex = 65;
            this.btnHastaReceteBul.Text = "HASTAYI BUL";
            this.btnHastaReceteBul.UseVisualStyleBackColor = true;
            this.btnHastaReceteBul.Click += new System.EventHandler(this.btnHastaReceteBul_Click);
            // 
            // dataGridViewReceteEkle
            // 
            this.dataGridViewReceteEkle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewReceteEkle.Location = new System.Drawing.Point(47, 31);
            this.dataGridViewReceteEkle.Name = "dataGridViewReceteEkle";
            this.dataGridViewReceteEkle.Size = new System.Drawing.Size(744, 108);
            this.dataGridViewReceteEkle.TabIndex = 64;
            // 
            // textBoxReceteBul
            // 
            this.textBoxReceteBul.Location = new System.Drawing.Point(215, 171);
            this.textBoxReceteBul.Name = "textBoxReceteBul";
            this.textBoxReceteBul.Size = new System.Drawing.Size(182, 20);
            this.textBoxReceteBul.TabIndex = 63;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(116, 174);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 13);
            this.label8.TabIndex = 62;
            this.label8.Text = "Hastanın TC\'si";
            // 
            // btnReceteEkleAnaSayfa
            // 
            this.btnReceteEkleAnaSayfa.Location = new System.Drawing.Point(645, 164);
            this.btnReceteEkleAnaSayfa.Name = "btnReceteEkleAnaSayfa";
            this.btnReceteEkleAnaSayfa.Size = new System.Drawing.Size(131, 33);
            this.btnReceteEkleAnaSayfa.TabIndex = 61;
            this.btnReceteEkleAnaSayfa.Text = "ANA SAYFAYA DÖN";
            this.btnReceteEkleAnaSayfa.UseVisualStyleBackColor = true;
            this.btnReceteEkleAnaSayfa.Click += new System.EventHandler(this.btnReceteEkleAnaSayfa_Click);
            // 
            // btnReceteEkleIptal
            // 
            this.btnReceteEkleIptal.Location = new System.Drawing.Point(538, 164);
            this.btnReceteEkleIptal.Name = "btnReceteEkleIptal";
            this.btnReceteEkleIptal.Size = new System.Drawing.Size(101, 33);
            this.btnReceteEkleIptal.TabIndex = 60;
            this.btnReceteEkleIptal.Text = "İPTAL";
            this.btnReceteEkleIptal.UseVisualStyleBackColor = true;
            this.btnReceteEkleIptal.Click += new System.EventHandler(this.btnReceteEkleIptal_Click);
            // 
            // textBoxHastaReceteNo
            // 
            this.textBoxHastaReceteNo.Location = new System.Drawing.Point(215, 306);
            this.textBoxHastaReceteNo.Name = "textBoxHastaReceteNo";
            this.textBoxHastaReceteNo.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaReceteNo.TabIndex = 57;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(72, 309);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 13);
            this.label6.TabIndex = 56;
            this.label6.Text = "Hastanın Recete NO\'su";
            // 
            // textBoxHastaTedavi
            // 
            this.textBoxHastaTedavi.Location = new System.Drawing.Point(560, 263);
            this.textBoxHastaTedavi.Name = "textBoxHastaTedavi";
            this.textBoxHastaTedavi.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaTedavi.TabIndex = 55;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(450, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 13);
            this.label5.TabIndex = 54;
            this.label5.Text = "Hastanın Tedavisi";
            // 
            // textBoxHastaTani
            // 
            this.textBoxHastaTani.Location = new System.Drawing.Point(215, 263);
            this.textBoxHastaTani.Name = "textBoxHastaTani";
            this.textBoxHastaTani.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaTani.TabIndex = 53;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(111, 263);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 52;
            this.label4.Text = "Hastanın Tanısı";
            // 
            // textBoxHastaSikayet
            // 
            this.textBoxHastaSikayet.Location = new System.Drawing.Point(560, 218);
            this.textBoxHastaSikayet.Name = "textBoxHastaSikayet";
            this.textBoxHastaSikayet.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaSikayet.TabIndex = 51;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(453, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "Hastanın Şikayeti";
            // 
            // textBoxMuayeneTarihi
            // 
            this.textBoxMuayeneTarihi.Location = new System.Drawing.Point(215, 218);
            this.textBoxMuayeneTarihi.Name = "textBoxMuayeneTarihi";
            this.textBoxMuayeneTarihi.Size = new System.Drawing.Size(182, 20);
            this.textBoxMuayeneTarihi.TabIndex = 49;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 48;
            this.label2.Text = "Hastanın Muayene Tarihi";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridViewReceteEkle);
            this.groupBox1.Controls.Add(this.btnHastaReceteBul);
            this.groupBox1.Controls.Add(this.btnReceteEkleVeriGuncelle);
            this.groupBox1.Controls.Add(this.btnYeniReceteEkle);
            this.groupBox1.Controls.Add(this.textBoxReceteBul);
            this.groupBox1.Controls.Add(this.textBoxHastaSikayet);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.btnReceteEkleIptal);
            this.groupBox1.Controls.Add(this.btnReceteEkleAnaSayfa);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxHastaReceteNo);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBoxHastaTedavi);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxHastaTani);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBoxMuayeneTarihi);
            this.groupBox1.Location = new System.Drawing.Point(22, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(844, 364);
            this.groupBox1.TabIndex = 73;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "REÇETE EKLE";
            // 
            // btnReceteEkleVeriGuncelle
            // 
            this.btnReceteEkleVeriGuncelle.Location = new System.Drawing.Point(606, 306);
            this.btnReceteEkleVeriGuncelle.Name = "btnReceteEkleVeriGuncelle";
            this.btnReceteEkleVeriGuncelle.Size = new System.Drawing.Size(136, 33);
            this.btnReceteEkleVeriGuncelle.TabIndex = 67;
            this.btnReceteEkleVeriGuncelle.Text = "VERİLERİ GÜNCELLE";
            this.btnReceteEkleVeriGuncelle.UseVisualStyleBackColor = true;
            this.btnReceteEkleVeriGuncelle.Click += new System.EventHandler(this.btnReceteEkleVerGuncelle_Click);
            // 
            // btnYeniReceteEkle
            // 
            this.btnYeniReceteEkle.Location = new System.Drawing.Point(443, 306);
            this.btnYeniReceteEkle.Name = "btnYeniReceteEkle";
            this.btnYeniReceteEkle.Size = new System.Drawing.Size(144, 33);
            this.btnYeniReceteEkle.TabIndex = 66;
            this.btnYeniReceteEkle.Text = "YENİ BİR REÇETE EKLE";
            this.btnYeniReceteEkle.UseVisualStyleBackColor = true;
            this.btnYeniReceteEkle.Click += new System.EventHandler(this.btnYeniReceteEkle_Click);
            // 
            // ReceteEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(897, 413);
            this.Controls.Add(this.groupBox1);
            this.Name = "ReceteEkle";
            this.Text = "ReceteEkle";
            this.Load += new System.EventHandler(this.ReceteEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReceteEkle)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnHastaReceteBul;
        private System.Windows.Forms.DataGridView dataGridViewReceteEkle;
        private System.Windows.Forms.TextBox textBoxReceteBul;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnReceteEkleAnaSayfa;
        private System.Windows.Forms.Button btnReceteEkleIptal;
        private System.Windows.Forms.TextBox textBoxHastaReceteNo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxHastaTedavi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxHastaTani;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxHastaSikayet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxMuayeneTarihi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnReceteEkleVeriGuncelle;
        private System.Windows.Forms.Button btnYeniReceteEkle;
    }
}