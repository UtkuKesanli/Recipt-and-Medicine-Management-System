﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class HastaSil : Form
    {
        public HastaSil()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        private void HastaSil_Load(object sender, EventArgs e)
        {

        }

        private void btnHastaSil_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaSil = new NpgsqlCommand();
            HastaSil.Connection = conn;
            HastaSil.Parameters.AddWithValue("@HastaTC", Convert.ToDouble(textBoxHastaSil.Text));
            HastaSil.CommandType = CommandType.Text;
            HastaSil.CommandText = "DELETE FROM \"Hastalar\" WHERE \"HastaTCNo\" = @HastaTC";
            HastaSil.CommandText = "DELETE FROM \"Receteler\" WHERE \"HastaTCNo\" = @HastaTC";
            HastaSil.CommandText = "DELETE FROM \"Muayeneler\" WHERE \"HastaTCNo\" = @HastaTC";
            NpgsqlDataReader dr = HastaSil.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
            }

            HastaSil.Dispose();
            conn.Close();
            textBoxHastaSil.Clear();
            dataGridViewHastaSil.Columns.Clear();
            MessageBox.Show("Seçtiğiniz hasta başarılı bir şekilde sistemden silinmiştir.", "HASTA SİLİNDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            this.Hide();
            HastaListesi HL = new HastaListesi();
            HL.Show();
        }

        private void btnHastaSilIptal_Click(object sender, EventArgs e)
        {
            this.Hide();
            HastaListesi HL = new HastaListesi();
            HL.Show();
        }

        private void btnHaslaSilAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }

        private void btnHastaSilBul_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaSil = new NpgsqlCommand();
            HastaSil.Connection = conn;
            HastaSil.Parameters.AddWithValue("@HastaTC", Convert.ToDouble(textBoxHastaSil.Text));
            HastaSil.CommandType = CommandType.Text;
            HastaSil.CommandText = "SELECT * FROM \"Hastalar\" WHERE \"HastaTCNo\" = @HastaTC";
            NpgsqlDataReader dr = HastaSil.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaSil.DataSource = dt;
            }

            HastaSil.Dispose();
            conn.Close();
        }
    }
}
