﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class IlacEkle : Form
    {
        public IlacEkle()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        private void IlacEkle_Load(object sender, EventArgs e)
        {

        }

        private void btnIlacEkle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand IlacEkle = new NpgsqlCommand();
            IlacEkle.Connection = conn;
            IlacEkle.Parameters.AddWithValue("@IlacBarkodNo", Convert.ToDouble(textBoxIlacBarkodNo.Text));
            IlacEkle.Parameters.AddWithValue("@IlacIsim", textBoxIlacIsim.Text);
            IlacEkle.Parameters.AddWithValue("@IlacTipi", textBoxIlacTipi.Text);
            IlacEkle.CommandType = CommandType.Text;
            IlacEkle.CommandText = "INSERT INTO public.\"Ilaclar\"(\r\n\t\"IlacBarkodNo\", \"IlacIsim\", \"IlacTipi\",)\r\n\tVALUES (@IlacBarkodNo, @IlacIsim, @IlacTipi);";
            NpgsqlDataReader dr = IlacEkle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
            }

            IlacEkle.Dispose();
            conn.Close();
            textBoxIlacBarkodNo.Clear();
            textBoxIlacIsim.Clear();
            textBoxIlacTipi.Clear();
            MessageBox.Show("Yeni bir ilaç başarılı bir şekilde eklenmiştir.", "İLAÇ EKLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Hide();
            IlacListesi IL = new IlacListesi();
            IL.Show();
        }

        private void btnIlacEkleIptal_Click(object sender, EventArgs e)
        {
            this.Hide();
            IlacListesi IL = new IlacListesi();
            IL.Show();
        }

        private void btnIlacEkleAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
