﻿namespace VeriProje
{
    partial class MuayeneListesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMuayeneListeAnaSayfa = new System.Windows.Forms.Button();
            this.btnBirReceteYaz = new System.Windows.Forms.Button();
            this.btnYeniMuayeneEkle = new System.Windows.Forms.Button();
            this.dataGridViewMuayeneListesi = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMuayeneListesi)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnMuayeneListeAnaSayfa
            // 
            this.btnMuayeneListeAnaSayfa.Location = new System.Drawing.Point(702, 208);
            this.btnMuayeneListeAnaSayfa.Name = "btnMuayeneListeAnaSayfa";
            this.btnMuayeneListeAnaSayfa.Size = new System.Drawing.Size(145, 62);
            this.btnMuayeneListeAnaSayfa.TabIndex = 12;
            this.btnMuayeneListeAnaSayfa.Text = "ANA SAYAFAYA DÖN";
            this.btnMuayeneListeAnaSayfa.UseVisualStyleBackColor = true;
            this.btnMuayeneListeAnaSayfa.Click += new System.EventHandler(this.btnMuayeneListeAnaSayfa_Click);
            // 
            // btnBirReceteYaz
            // 
            this.btnBirReceteYaz.Location = new System.Drawing.Point(702, 120);
            this.btnBirReceteYaz.Name = "btnBirReceteYaz";
            this.btnBirReceteYaz.Size = new System.Drawing.Size(145, 62);
            this.btnBirReceteYaz.TabIndex = 11;
            this.btnBirReceteYaz.Text = "BİR HASTAYA REÇETE EKLE";
            this.btnBirReceteYaz.UseVisualStyleBackColor = true;
            this.btnBirReceteYaz.Click += new System.EventHandler(this.btnBirReceteYaz_Click);
            // 
            // btnYeniMuayeneEkle
            // 
            this.btnYeniMuayeneEkle.Location = new System.Drawing.Point(702, 34);
            this.btnYeniMuayeneEkle.Name = "btnYeniMuayeneEkle";
            this.btnYeniMuayeneEkle.Size = new System.Drawing.Size(145, 62);
            this.btnYeniMuayeneEkle.TabIndex = 9;
            this.btnYeniMuayeneEkle.Text = "YENİ BİR MUAYENE EKLE";
            this.btnYeniMuayeneEkle.UseVisualStyleBackColor = true;
            this.btnYeniMuayeneEkle.Click += new System.EventHandler(this.btnYeniMuayeneEkle_Click);
            // 
            // dataGridViewMuayeneListesi
            // 
            this.dataGridViewMuayeneListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMuayeneListesi.Location = new System.Drawing.Point(55, 63);
            this.dataGridViewMuayeneListesi.Name = "dataGridViewMuayeneListesi";
            this.dataGridViewMuayeneListesi.Size = new System.Drawing.Size(642, 236);
            this.dataGridViewMuayeneListesi.TabIndex = 8;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnMuayeneListeAnaSayfa);
            this.groupBox1.Controls.Add(this.btnYeniMuayeneEkle);
            this.groupBox1.Controls.Add(this.btnBirReceteYaz);
            this.groupBox1.Location = new System.Drawing.Point(27, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(875, 301);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MUAYENE LİSTESİ";
            // 
            // MuayeneListesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(932, 360);
            this.Controls.Add(this.dataGridViewMuayeneListesi);
            this.Controls.Add(this.groupBox1);
            this.Name = "MuayeneListesi";
            this.Text = "MuayeneListesi";
            this.Load += new System.EventHandler(this.MuayeneListesi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMuayeneListesi)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMuayeneListeAnaSayfa;
        private System.Windows.Forms.Button btnBirReceteYaz;
        private System.Windows.Forms.Button btnYeniMuayeneEkle;
        private System.Windows.Forms.DataGridView dataGridViewMuayeneListesi;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}