﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class HastaGuncelle : Form
    {
        public HastaGuncelle()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        private void HastaGuncelle_Load(object sender, EventArgs e)
        {

        }

        public void VerileriGoster()
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaTC", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "SELECT * FROM \"Hastalar\" WHERE \"HastaTCNo\" = @HastaTC";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
        }

        private void btnHastaGuncelleBul_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaTC", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "SELECT * FROM \"Hastalar\" WHERE \"HastaTCNo\" = @HastaTC";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
            textBoxHastaGuncelle.Clear();
        }

        private void btnHastaGuncelleIptal_Click(object sender, EventArgs e)
        {
            this.Hide();
            HastaListesi HL = new HastaListesi();
            HL.Show();
        }

        private void btnHastaGuncelleAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }

        private void btnHastaTCGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaGuncelleAl", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.Parameters.AddWithValue("@HastaTC", Convert.ToDouble(textBoxHastaTC.Text));
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "UPDATE \"Hastalar\" SET \"HastaTCNo\" = @HastaTC WHERE \"HastaTCNo\" = @HastaGuncelleAl";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
            textBoxHastaTC.Clear();
            MessageBox.Show("Hastanın TC'si başarılı bir şekilde güncellenmiştir.", "HASTA TC GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnHastaIsimGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaGuncelleAl", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.Parameters.AddWithValue("@HastaIsim", textBoxHastaIsim.Text);
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "UPDATE \"Hastalar\" SET \"HastaIsim\" = @HastaIsim WHERE \"HastaTCNo\" = @HastaGuncelleAl";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
            textBoxHastaIsim.Clear();
            MessageBox.Show("Hastanın ismi ve soyismi başarılı bir şekilde güncellenmiştir.", "HASTA İSİM GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnHastaDogumYeriGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaGuncelleAl", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.Parameters.AddWithValue("@HastaDogumYeri", textBoxHastaDogumYeri.Text);
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "UPDATE \"Hastalar\" SET \"HastaDogumYeri\" = @HastaDogumYeri WHERE \"HastaTCNo\" = @HastaGuncelleAl";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
            textBoxHastaDogumYeri.Clear();
            MessageBox.Show("Hastanın Dogğum Yeri başarılı bir şekilde güncellenmiştir.", "HASTA DOĞUM YERİ GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnHastaAdresGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaGuncelleAl", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.Parameters.AddWithValue("@HastaAdres", textBoxHastaAdresi.Text);
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "UPDATE \"Hastalar\" SET \"HastaAdres\" = @HastaAdres WHERE \"HastaTCNo\" = @HastaGuncelleAl";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
            textBoxHastaAdresi.Clear();
            MessageBox.Show("Hastanın adresi başarılı bir şekilde güncellenmiştir.", "HASTA ADRES GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnHastaTelNOGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaGuncelleAl", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.Parameters.AddWithValue("@HastaTelNO", textBoxHastaTelNO.Text);
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "UPDATE \"Hastalar\" SET \"HastaTelNo\" = @HastaTelNO WHERE \"HastaTCNo\" = @HastaGuncelleAl";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
            textBoxHastaTelNO.Clear();
            MessageBox.Show("Hastanın telefon numarası başarılı bir şekilde güncellenmiştir.", "HASTA TEL NO GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnHastaMedeniDurumGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaGuncelleAl", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.Parameters.AddWithValue("@HastaMedeniDurum", textBoxHastaMedeniDurum.Text);
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "UPDATE \"Hastalar\" SET \"HastaMedeniDurum\" = @HastaMedeniDurum WHERE \"HastaTCNo\" = @HastaGuncelleAl";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
            textBoxHastaMedeniDurum.Clear();
            MessageBox.Show("Hastanın medeni durumu başarılı bir şekilde güncellenmiştir.", "HASTA MEDENİ DURUM GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnHastaDogumGunuGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaGuncelle = new NpgsqlCommand();
            HastaGuncelle.Connection = conn;
            HastaGuncelle.Parameters.AddWithValue("@HastaGuncelleAl", Convert.ToDouble(textBoxHastaGuncelle.Text));
            HastaGuncelle.Parameters.AddWithValue("@HastaDogumGunu", textBoxHastaDogumGunu.Text);
            HastaGuncelle.CommandType = CommandType.Text;
            HastaGuncelle.CommandText = "UPDATE \"Hastalar\" SET \"HastaDogumGunu\" = @HastaDogumGunu WHERE \"HastaTCNo\" = @HastaGuncelleAl";
            NpgsqlDataReader dr = HastaGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaGuncelle.DataSource = dt;
            }

            HastaGuncelle.Dispose();
            conn.Close();
            textBoxHastaDogumGunu.Clear();
            MessageBox.Show("Hastanın doğum günü başarılı bir şekilde güncellenmiştir.", "HASTA DOĞUM GÜNÜ GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }
    }
}
