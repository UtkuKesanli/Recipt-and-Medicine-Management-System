﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class IlacGuncelle : Form
    {
        public IlacGuncelle()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        public void VerileriGoster()
        {
            conn.Open();
            NpgsqlCommand IlacGuncelle = new NpgsqlCommand();
            IlacGuncelle.Connection = conn;
            IlacGuncelle.Parameters.AddWithValue("@IlacBarkodNo", Convert.ToDouble(textBoxIlacGuncelle.Text));
            IlacGuncelle.CommandType = CommandType.Text;
            IlacGuncelle.CommandText = "SELECT * FROM \"Ilaclar\" WHERE \"IlacBarkodNo\" = @IlacBarkodNo";
            NpgsqlDataReader dr = IlacGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewIlacGuncelle.DataSource = dt;
            }

            IlacGuncelle.Dispose();
            conn.Close();
        }

        private void IlacGuncelle_Load(object sender, EventArgs e)
        {

        }

        private void btnIlacGuncelleBul_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand IlacGuncelle = new NpgsqlCommand();
            IlacGuncelle.Connection = conn;
            IlacGuncelle.Parameters.AddWithValue("@IlacBarkodNo", Convert.ToDouble(textBoxIlacGuncelle.Text));
            IlacGuncelle.CommandType = CommandType.Text;
            IlacGuncelle.CommandText = "SELECT * FROM \"Ilaclar\" WHERE \"IlacBarkodNo\" = @IlacBarkodNo";
            NpgsqlDataReader dr = IlacGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewIlacGuncelle.DataSource = dt;
            }

            IlacGuncelle.Dispose();
            conn.Close();
        }

        private void btnIlacBarkodNoGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand IlacGuncelle = new NpgsqlCommand();
            IlacGuncelle.Connection = conn;
            IlacGuncelle.Parameters.AddWithValue("@IlacBarkodNoAl", Convert.ToDouble(textBoxIlacGuncelle.Text));
            IlacGuncelle.Parameters.AddWithValue("@IlacBarkodNo", Convert.ToDouble(textBoxIlacBarkodNo.Text));
            IlacGuncelle.CommandType = CommandType.Text;
            IlacGuncelle.CommandText = "UPDATE \"Ilaclar\" SET \"IlacBarkodNo\" = @IlacBarkodNo WHERE \"IlacBarkodNo\" = @IlacBarkodNoAl";
            NpgsqlDataReader dr = IlacGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewIlacGuncelle.DataSource = dt;
            }

            IlacGuncelle.Dispose();
            conn.Close();
            textBoxIlacBarkodNo.Clear();
            MessageBox.Show("İlacın barkod NO'su başarılı bir şekilde güncellenmiştir.", "İLAÇ BARKOD NO GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnIlacIsimGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand IlacGuncelle = new NpgsqlCommand();
            IlacGuncelle.Connection = conn;
            IlacGuncelle.Parameters.AddWithValue("@IlacBarkodNoAl", Convert.ToDouble(textBoxIlacGuncelle.Text));
            IlacGuncelle.Parameters.AddWithValue("@IlacIsim", textBoxIlacIsmi.Text);
            IlacGuncelle.CommandType = CommandType.Text;
            IlacGuncelle.CommandText = "UPDATE \"Ilaclar\" SET \"IlacIsim\" = @IlacIsim WHERE \"IlacBarkodNo\" = @IlacBarkodNoAl";
            NpgsqlDataReader dr = IlacGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewIlacGuncelle.DataSource = dt;
            }

            IlacGuncelle.Dispose();
            conn.Close();
            textBoxIlacBarkodNo.Clear();
            MessageBox.Show("İlacın ismi başarılı bir şekilde güncellenmiştir.", "İLAÇ İSMİ GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnIlacTipiGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand IlacGuncelle = new NpgsqlCommand();
            IlacGuncelle.Connection = conn;
            IlacGuncelle.Parameters.AddWithValue("@IlacBarkodNoAl", Convert.ToDouble(textBoxIlacGuncelle.Text));
            IlacGuncelle.Parameters.AddWithValue("@IlacTipi", textBoxIlacTipi.Text);
            IlacGuncelle.CommandType = CommandType.Text;
            IlacGuncelle.CommandText = "UPDATE \"Ilaclar\" SET \"IlacTipi\" = @IlacTipi WHERE \"IlacBarkodNo\" = @IlacBarkodNoAl";
            NpgsqlDataReader dr = IlacGuncelle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewIlacGuncelle.DataSource = dt;
            }

            IlacGuncelle.Dispose();
            conn.Close();
            textBoxIlacBarkodNo.Clear();
            MessageBox.Show("İlacın tipi başarılı bir şekilde güncellenmiştir.", "İLAÇ TİPİ GÜNCELLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            VerileriGoster();
        }

        private void btnIlacGuncelleIptal_Click(object sender, EventArgs e)
        {
            this.Hide();
            IlacListesi IL = new IlacListesi();
            IL.Show();
        }

        private void btnIlacGuncelleAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
