﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class MuayeneListesi : Form
    {
        public MuayeneListesi()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        public void VerileriGoster()
        {
            conn.Open();
            NpgsqlCommand veriler = new NpgsqlCommand();
            veriler.Connection = conn;
            veriler.CommandType = CommandType.Text;
            veriler.CommandText = "SELECT \"MuayeneTarihi\",\"HastaIsim\",\"HastaDogumTarihi\",\"HastaBulgular\",\"HastaTeshis\",\"HastaTedavi\" FROM Public.\"Muayeneler\" ORDER BY \"Muayeneler\" ASC";
            NpgsqlDataReader dr = veriler.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewMuayeneListesi.DataSource = dt;
            }

            veriler.Dispose();
            conn.Close();
        }

        private void MuayeneListesi_Load(object sender, EventArgs e)
        {
            VerileriGoster();
        }

        private void btnYeniMuayeneEkle_Click(object sender, EventArgs e)
        {
            this.Hide();
            MuayeneEkle ME = new MuayeneEkle();
            ME.Show();
        }

        private void btnBirReceteYaz_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReceteEkle RE = new ReceteEkle();
            RE.Show();
        }

        private void btnMuayeneListeAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
