﻿namespace VeriProje
{
    partial class IlacEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIlacEkleAnaSayfa = new System.Windows.Forms.Button();
            this.btnIlacEkleIptal = new System.Windows.Forms.Button();
            this.btnIlacEkle = new System.Windows.Forms.Button();
            this.textBoxIlacTipi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxIlacIsim = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxIlacBarkodNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // btnIlacEkleAnaSayfa
            // 
            this.btnIlacEkleAnaSayfa.Location = new System.Drawing.Point(396, 186);
            this.btnIlacEkleAnaSayfa.Name = "btnIlacEkleAnaSayfa";
            this.btnIlacEkleAnaSayfa.Size = new System.Drawing.Size(145, 62);
            this.btnIlacEkleAnaSayfa.TabIndex = 19;
            this.btnIlacEkleAnaSayfa.Text = "ANA SAYFAYA DÖN";
            this.btnIlacEkleAnaSayfa.UseVisualStyleBackColor = true;
            this.btnIlacEkleAnaSayfa.Click += new System.EventHandler(this.btnIlacEkleAnaSayfa_Click);
            // 
            // btnIlacEkleIptal
            // 
            this.btnIlacEkleIptal.Location = new System.Drawing.Point(229, 186);
            this.btnIlacEkleIptal.Name = "btnIlacEkleIptal";
            this.btnIlacEkleIptal.Size = new System.Drawing.Size(145, 62);
            this.btnIlacEkleIptal.TabIndex = 18;
            this.btnIlacEkleIptal.Text = "İPTAL";
            this.btnIlacEkleIptal.UseVisualStyleBackColor = true;
            this.btnIlacEkleIptal.Click += new System.EventHandler(this.btnIlacEkleIptal_Click);
            // 
            // btnIlacEkle
            // 
            this.btnIlacEkle.Location = new System.Drawing.Point(63, 186);
            this.btnIlacEkle.Name = "btnIlacEkle";
            this.btnIlacEkle.Size = new System.Drawing.Size(145, 62);
            this.btnIlacEkle.TabIndex = 17;
            this.btnIlacEkle.Text = "YENİ BİR İLAÇ EKLE";
            this.btnIlacEkle.UseVisualStyleBackColor = true;
            this.btnIlacEkle.Click += new System.EventHandler(this.btnIlacEkle_Click);
            // 
            // textBoxIlacTipi
            // 
            this.textBoxIlacTipi.Location = new System.Drawing.Point(254, 139);
            this.textBoxIlacTipi.Name = "textBoxIlacTipi";
            this.textBoxIlacTipi.Size = new System.Drawing.Size(182, 20);
            this.textBoxIlacTipi.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(155, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "İlaç Tipi";
            // 
            // textBoxIlacIsim
            // 
            this.textBoxIlacIsim.Location = new System.Drawing.Point(254, 102);
            this.textBoxIlacIsim.Name = "textBoxIlacIsim";
            this.textBoxIlacIsim.Size = new System.Drawing.Size(182, 20);
            this.textBoxIlacIsim.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(155, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "İlaç İsmi";
            // 
            // textBoxIlacBarkodNo
            // 
            this.textBoxIlacBarkodNo.Location = new System.Drawing.Point(254, 67);
            this.textBoxIlacBarkodNo.Name = "textBoxIlacBarkodNo";
            this.textBoxIlacBarkodNo.Size = new System.Drawing.Size(182, 20);
            this.textBoxIlacBarkodNo.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(155, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "İlaç Barkod NO";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(30, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(541, 244);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İLAÇ EKLE";
            // 
            // IlacEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(606, 309);
            this.Controls.Add(this.textBoxIlacTipi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxIlacIsim);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxIlacBarkodNo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIlacEkleAnaSayfa);
            this.Controls.Add(this.btnIlacEkleIptal);
            this.Controls.Add(this.btnIlacEkle);
            this.Controls.Add(this.groupBox1);
            this.Name = "IlacEkle";
            this.Text = "IlacEkle";
            this.Load += new System.EventHandler(this.IlacEkle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIlacEkleAnaSayfa;
        private System.Windows.Forms.Button btnIlacEkleIptal;
        private System.Windows.Forms.Button btnIlacEkle;
        private System.Windows.Forms.TextBox textBoxIlacTipi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxIlacIsim;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxIlacBarkodNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}