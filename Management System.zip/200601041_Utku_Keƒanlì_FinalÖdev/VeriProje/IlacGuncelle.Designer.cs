﻿namespace VeriProje
{
    partial class IlacGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIlacTipiGuncelle = new System.Windows.Forms.Button();
            this.btnIlacIsimGuncelle = new System.Windows.Forms.Button();
            this.btnIlacBarkodNoGuncelle = new System.Windows.Forms.Button();
            this.btnIlacGuncelleBul = new System.Windows.Forms.Button();
            this.textBoxIlacGuncelle = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnIlacGuncelleAnaSayfa = new System.Windows.Forms.Button();
            this.btnIlacGuncelleIptal = new System.Windows.Forms.Button();
            this.textBoxIlacTipi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxIlacIsmi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxIlacBarkodNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridViewIlacGuncelle = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIlacGuncelle)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIlacTipiGuncelle
            // 
            this.btnIlacTipiGuncelle.Location = new System.Drawing.Point(439, 292);
            this.btnIlacTipiGuncelle.Name = "btnIlacTipiGuncelle";
            this.btnIlacTipiGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnIlacTipiGuncelle.TabIndex = 64;
            this.btnIlacTipiGuncelle.Text = "GÜNCELLE";
            this.btnIlacTipiGuncelle.UseVisualStyleBackColor = true;
            this.btnIlacTipiGuncelle.Click += new System.EventHandler(this.btnIlacTipiGuncelle_Click);
            // 
            // btnIlacIsimGuncelle
            // 
            this.btnIlacIsimGuncelle.Location = new System.Drawing.Point(439, 255);
            this.btnIlacIsimGuncelle.Name = "btnIlacIsimGuncelle";
            this.btnIlacIsimGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnIlacIsimGuncelle.TabIndex = 63;
            this.btnIlacIsimGuncelle.Text = "GÜNCELLE";
            this.btnIlacIsimGuncelle.UseVisualStyleBackColor = true;
            this.btnIlacIsimGuncelle.Click += new System.EventHandler(this.btnIlacIsimGuncelle_Click);
            // 
            // btnIlacBarkodNoGuncelle
            // 
            this.btnIlacBarkodNoGuncelle.Location = new System.Drawing.Point(439, 220);
            this.btnIlacBarkodNoGuncelle.Name = "btnIlacBarkodNoGuncelle";
            this.btnIlacBarkodNoGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnIlacBarkodNoGuncelle.TabIndex = 62;
            this.btnIlacBarkodNoGuncelle.Text = "GÜNCELLE";
            this.btnIlacBarkodNoGuncelle.UseVisualStyleBackColor = true;
            this.btnIlacBarkodNoGuncelle.Click += new System.EventHandler(this.btnIlacBarkodNoGuncelle_Click);
            // 
            // btnIlacGuncelleBul
            // 
            this.btnIlacGuncelleBul.Location = new System.Drawing.Point(484, 166);
            this.btnIlacGuncelleBul.Name = "btnIlacGuncelleBul";
            this.btnIlacGuncelleBul.Size = new System.Drawing.Size(91, 33);
            this.btnIlacGuncelleBul.TabIndex = 61;
            this.btnIlacGuncelleBul.Text = "İLACI BUL";
            this.btnIlacGuncelleBul.UseVisualStyleBackColor = true;
            this.btnIlacGuncelleBul.Click += new System.EventHandler(this.btnIlacGuncelleBul_Click);
            // 
            // textBoxIlacGuncelle
            // 
            this.textBoxIlacGuncelle.Location = new System.Drawing.Point(271, 173);
            this.textBoxIlacGuncelle.Name = "textBoxIlacGuncelle";
            this.textBoxIlacGuncelle.Size = new System.Drawing.Size(182, 20);
            this.textBoxIlacGuncelle.TabIndex = 59;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(151, 176);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 13);
            this.label8.TabIndex = 58;
            this.label8.Text = "İlacın Barkod NO\'su";
            // 
            // btnIlacGuncelleAnaSayfa
            // 
            this.btnIlacGuncelleAnaSayfa.Location = new System.Drawing.Point(585, 234);
            this.btnIlacGuncelleAnaSayfa.Name = "btnIlacGuncelleAnaSayfa";
            this.btnIlacGuncelleAnaSayfa.Size = new System.Drawing.Size(129, 45);
            this.btnIlacGuncelleAnaSayfa.TabIndex = 57;
            this.btnIlacGuncelleAnaSayfa.Text = "ANA SAYFAYA DÖN";
            this.btnIlacGuncelleAnaSayfa.UseVisualStyleBackColor = true;
            this.btnIlacGuncelleAnaSayfa.Click += new System.EventHandler(this.btnIlacGuncelleAnaSayfa_Click);
            // 
            // btnIlacGuncelleIptal
            // 
            this.btnIlacGuncelleIptal.Location = new System.Drawing.Point(585, 177);
            this.btnIlacGuncelleIptal.Name = "btnIlacGuncelleIptal";
            this.btnIlacGuncelleIptal.Size = new System.Drawing.Size(129, 43);
            this.btnIlacGuncelleIptal.TabIndex = 56;
            this.btnIlacGuncelleIptal.Text = "İPTAL";
            this.btnIlacGuncelleIptal.UseVisualStyleBackColor = true;
            this.btnIlacGuncelleIptal.Click += new System.EventHandler(this.btnIlacGuncelleIptal_Click);
            // 
            // textBoxIlacTipi
            // 
            this.textBoxIlacTipi.Location = new System.Drawing.Point(212, 295);
            this.textBoxIlacTipi.Name = "textBoxIlacTipi";
            this.textBoxIlacTipi.Size = new System.Drawing.Size(182, 20);
            this.textBoxIlacTipi.TabIndex = 51;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(122, 298);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "İlaç Tipi";
            // 
            // textBoxIlacIsmi
            // 
            this.textBoxIlacIsmi.Location = new System.Drawing.Point(212, 258);
            this.textBoxIlacIsmi.Name = "textBoxIlacIsmi";
            this.textBoxIlacIsmi.Size = new System.Drawing.Size(182, 20);
            this.textBoxIlacIsmi.TabIndex = 49;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(122, 261);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 48;
            this.label2.Text = "İlaç İsmi";
            // 
            // textBoxIlacBarkodNo
            // 
            this.textBoxIlacBarkodNo.Location = new System.Drawing.Point(212, 223);
            this.textBoxIlacBarkodNo.Name = "textBoxIlacBarkodNo";
            this.textBoxIlacBarkodNo.Size = new System.Drawing.Size(182, 20);
            this.textBoxIlacBarkodNo.TabIndex = 47;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(101, 227);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 46;
            this.label1.Text = "İlacın Barkod NO";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridViewIlacGuncelle);
            this.groupBox1.Controls.Add(this.btnIlacGuncelleAnaSayfa);
            this.groupBox1.Controls.Add(this.btnIlacGuncelleIptal);
            this.groupBox1.Location = new System.Drawing.Point(25, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(792, 321);
            this.groupBox1.TabIndex = 67;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "HASTA GÜNCELLE";
            // 
            // dataGridViewIlacGuncelle
            // 
            this.dataGridViewIlacGuncelle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIlacGuncelle.Location = new System.Drawing.Point(223, 37);
            this.dataGridViewIlacGuncelle.Name = "dataGridViewIlacGuncelle";
            this.dataGridViewIlacGuncelle.Size = new System.Drawing.Size(348, 69);
            this.dataGridViewIlacGuncelle.TabIndex = 58;
            // 
            // IlacGuncelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(845, 387);
            this.Controls.Add(this.btnIlacTipiGuncelle);
            this.Controls.Add(this.btnIlacIsimGuncelle);
            this.Controls.Add(this.btnIlacBarkodNoGuncelle);
            this.Controls.Add(this.btnIlacGuncelleBul);
            this.Controls.Add(this.textBoxIlacGuncelle);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxIlacTipi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxIlacIsmi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxIlacBarkodNo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "IlacGuncelle";
            this.Text = "IlacGuncelle";
            this.Load += new System.EventHandler(this.IlacGuncelle_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIlacGuncelle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIlacTipiGuncelle;
        private System.Windows.Forms.Button btnIlacIsimGuncelle;
        private System.Windows.Forms.Button btnIlacBarkodNoGuncelle;
        private System.Windows.Forms.Button btnIlacGuncelleBul;
        private System.Windows.Forms.TextBox textBoxIlacGuncelle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnIlacGuncelleAnaSayfa;
        private System.Windows.Forms.Button btnIlacGuncelleIptal;
        private System.Windows.Forms.TextBox textBoxIlacTipi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxIlacIsmi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxIlacBarkodNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridViewIlacGuncelle;
    }
}