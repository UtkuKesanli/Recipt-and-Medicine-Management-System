﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class IlacListesi : Form
    {
        public IlacListesi()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        public void VerileriGoster()
        {
            conn.Open();
            NpgsqlCommand veriler = new NpgsqlCommand();
            veriler.Connection = conn;
            veriler.CommandType = CommandType.Text;
            veriler.CommandText = "SELECT * FROM Public.\"Ilaclar\"";
            NpgsqlDataReader dr = veriler.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewIlacListesi.DataSource = dt;
            }

            veriler.Dispose();
            conn.Close();
        }

        private void IlacListesi_Load(object sender, EventArgs e)
        {
            VerileriGoster();
        }

        private void btnYeniIlacEkle_Click(object sender, EventArgs e)
        {
            this.Hide();
            IlacEkle IE = new IlacEkle();
            IE.Show();
        }

        private void btnBirIlacSil_Click(object sender, EventArgs e)
        {
            this.Hide();
            IlacSil IS = new IlacSil();
            IS.Show();
        }

        private void btnBirIlacGuncelle_Click(object sender, EventArgs e)
        {
            this.Hide();
            IlacGuncelle IG = new IlacGuncelle();
            IG.Show();
        }

        private void btnHaslaIlacAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
