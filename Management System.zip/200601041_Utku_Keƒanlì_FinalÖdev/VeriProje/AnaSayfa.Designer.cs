﻿namespace VeriProje
{
    partial class AnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxAnaSayfa = new System.Windows.Forms.GroupBox();
            this.btnMuayeneListe = new System.Windows.Forms.Button();
            this.btnIlacListe = new System.Windows.Forms.Button();
            this.btnReceteListe = new System.Windows.Forms.Button();
            this.btnHastaListe = new System.Windows.Forms.Button();
            this.groupBoxAnaSayfa.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxAnaSayfa
            // 
            this.groupBoxAnaSayfa.Controls.Add(this.btnMuayeneListe);
            this.groupBoxAnaSayfa.Controls.Add(this.btnIlacListe);
            this.groupBoxAnaSayfa.Controls.Add(this.btnReceteListe);
            this.groupBoxAnaSayfa.Controls.Add(this.btnHastaListe);
            this.groupBoxAnaSayfa.Location = new System.Drawing.Point(25, 24);
            this.groupBoxAnaSayfa.Name = "groupBoxAnaSayfa";
            this.groupBoxAnaSayfa.Size = new System.Drawing.Size(373, 224);
            this.groupBoxAnaSayfa.TabIndex = 0;
            this.groupBoxAnaSayfa.TabStop = false;
            this.groupBoxAnaSayfa.Text = "MUAYENE BİLGİ YÖNETİM SİSTEMİ";
            // 
            // btnMuayeneListe
            // 
            this.btnMuayeneListe.Location = new System.Drawing.Point(202, 45);
            this.btnMuayeneListe.Name = "btnMuayeneListe";
            this.btnMuayeneListe.Size = new System.Drawing.Size(145, 62);
            this.btnMuayeneListe.TabIndex = 3;
            this.btnMuayeneListe.Text = "Muayenelerin Listesi";
            this.btnMuayeneListe.UseVisualStyleBackColor = true;
            this.btnMuayeneListe.Click += new System.EventHandler(this.btnMuayeneListe_Click);
            // 
            // btnIlacListe
            // 
            this.btnIlacListe.Location = new System.Drawing.Point(202, 128);
            this.btnIlacListe.Name = "btnIlacListe";
            this.btnIlacListe.Size = new System.Drawing.Size(145, 62);
            this.btnIlacListe.TabIndex = 2;
            this.btnIlacListe.Text = "İlaçların Listesi";
            this.btnIlacListe.UseVisualStyleBackColor = true;
            this.btnIlacListe.Click += new System.EventHandler(this.btnIlacListe_Click);
            // 
            // btnReceteListe
            // 
            this.btnReceteListe.Location = new System.Drawing.Point(27, 128);
            this.btnReceteListe.Name = "btnReceteListe";
            this.btnReceteListe.Size = new System.Drawing.Size(145, 62);
            this.btnReceteListe.TabIndex = 1;
            this.btnReceteListe.Text = "Reçete Listesi";
            this.btnReceteListe.UseVisualStyleBackColor = true;
            this.btnReceteListe.Click += new System.EventHandler(this.btnReceteListe_Click);
            // 
            // btnHastaListe
            // 
            this.btnHastaListe.Location = new System.Drawing.Point(27, 45);
            this.btnHastaListe.Name = "btnHastaListe";
            this.btnHastaListe.Size = new System.Drawing.Size(145, 62);
            this.btnHastaListe.TabIndex = 0;
            this.btnHastaListe.Text = "Hastaların Listesi";
            this.btnHastaListe.UseVisualStyleBackColor = true;
            this.btnHastaListe.Click += new System.EventHandler(this.btnHastaListe_Click);
            // 
            // AnaSayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(427, 280);
            this.Controls.Add(this.groupBoxAnaSayfa);
            this.Name = "AnaSayfa";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxAnaSayfa.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxAnaSayfa;
        private System.Windows.Forms.Button btnIlacListe;
        private System.Windows.Forms.Button btnReceteListe;
        private System.Windows.Forms.Button btnHastaListe;
        private System.Windows.Forms.Button btnMuayeneListe;
    }
}

