﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class ReceteListesi : Form
    {
        public ReceteListesi()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        public void VerileriGoster()
        {
            conn.Open();
            NpgsqlCommand veriler = new NpgsqlCommand();
            veriler.Connection = conn;
            veriler.CommandType = CommandType.Text;
            veriler.CommandText = "SELECT * FROM Public.\"Receteler\" ORDER BY \"MuayeneTarihi\" ASC";
            NpgsqlDataReader dr = veriler.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewReceteListe.DataSource = dt;
            }

            veriler.Dispose();
            conn.Close();
        }

        private void ReceteListesi_Load(object sender, EventArgs e)
        {
            VerileriGoster();
        }

        private void btnReceteListeBul_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand ReceteListe = new NpgsqlCommand();
            ReceteListe.Connection = conn;
            ReceteListe.Parameters.AddWithValue("@HastaTCNo", Convert.ToDouble(textBoxReceteBul.Text));
            ReceteListe.CommandType = CommandType.Text;
            ReceteListe.CommandText = "SELECT * FROM \"Receteler\" WHERE \"HastaTCNo\" = @HastaTCNo ORDER BY \"MuayeneTarihi\" ASC";
            NpgsqlDataReader dr = ReceteListe.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewReceteListe.DataSource = dt;
            }

            ReceteListe.Dispose();
            conn.Close();
        }

        private void btnReceteEkle_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReceteEkle RE = new ReceteEkle();
            RE.Show();
        }

        private void btnReceteListeAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
