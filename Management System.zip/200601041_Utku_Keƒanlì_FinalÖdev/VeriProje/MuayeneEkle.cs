﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class MuayeneEkle : Form
    {
        public MuayeneEkle()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        private void MuayeneEkle_Load(object sender, EventArgs e)
        {

        }

        private void btnHastaMuayeneBul_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand MuayeneEkle = new NpgsqlCommand();
            MuayeneEkle.Connection = conn;
            MuayeneEkle.Parameters.AddWithValue("@HastaTC", Convert.ToDouble(textBoxMuayeneBul.Text));
            MuayeneEkle.CommandType = CommandType.Text;
            MuayeneEkle.CommandText = "SELECT * FROM \"Muayeneler\" WHERE \"HastaTCNo\" = @HastaTC";
            NpgsqlDataReader dr = MuayeneEkle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewMuayeneEkle.DataSource = dt;
            }

            MuayeneEkle.Dispose();
            conn.Close();
        }

        private void btnYeniMuayeneEkle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand MuayeneEkle = new NpgsqlCommand();
            MuayeneEkle.CommandType = CommandType.Text;
            MuayeneEkle.Parameters.AddWithValue("@HastaTCNo", Convert.ToDouble(textBoxMuayeneBul.Text));

            DateTime YeniMuayeneTarihi = Convert.ToDateTime(textBoxMuayeneTarihi.Text);
            DateTime MuayeneTarihi = new DateTime();

            using (NpgsqlCommand MuayeneEkleKontrol = new NpgsqlCommand("SELECT \"MuayeneTarihi\" FROM \"Muayeneler\" WHERE \"HastaTCNo\" = @HastaTC", conn))
            {
                MuayeneEkleKontrol.Parameters.AddWithValue("@HastaTC", Convert.ToDouble(textBoxMuayeneBul.Text));
                using (var reader = MuayeneEkleKontrol.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        MuayeneTarihi = reader.GetDateTime(0);
                    }
                }
            }

            TimeSpan difference = YeniMuayeneTarihi - MuayeneTarihi;

            double Kontrol = Convert.ToInt32(difference.Days);

            if (Kontrol < 1)
            {
                MessageBox.Show("Hastayanın bugün içinde zaten bir muayene hakkını doldurdu.", "MUAYENE OLUŞTURULAMADI", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else {
                conn.Open();
                MuayeneEkle.Connection = conn;
                MuayeneEkle.Parameters.AddWithValue("@HastaTCNo", Convert.ToDouble(textBoxMuayeneBul.Text));
                MuayeneEkle.Parameters.AddWithValue("@MuayeneTarihi", Convert.ToDateTime(textBoxMuayeneTarihi.Text));
                MuayeneEkle.Parameters.AddWithValue("@HastaIsim", textBoxHastaIsim.Text);
                MuayeneEkle.Parameters.AddWithValue("@HastaDogumTarihi", Convert.ToDateTime(textBoxHastaDogumTarihi.Text));
                MuayeneEkle.Parameters.AddWithValue("@HastaBulgular", textBoxHastaBulgular.Text);
                MuayeneEkle.Parameters.AddWithValue("@HastaTeshis", textBoxHastaTeshis.Text);
                MuayeneEkle.Parameters.AddWithValue("@HastaTedavisi", textBoxHastaTedavisi.Text);
                MuayeneEkle.CommandType = CommandType.Text;
                MuayeneEkle.CommandText = "INSERT INTO public.\"Muayeneler\"(\r\n\t\"HastaTCNo\", \"MuayeneTarihi\", \"HastaIsim\", \"HastaDogumTarihi\", \"HastaBulgular\", \"HastaTeshis\", \"HastaTedavisi\")\r\n\tVALUES (@HastaTCNo, @MuayeneTarihi, @HastaIsim, @HastaDogumTarihi, @HastaBulgular, @HastaTeshis, @HastaTedavisi);";
                NpgsqlDataReader dr = MuayeneEkle.ExecuteReader();

                if (dr.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Load(dr);
                }

                MuayeneEkle.Dispose();
                conn.Close();
                textBoxMuayeneTarihi.Clear();
                textBoxHastaIsim.Clear();
                textBoxHastaDogumTarihi.Clear();
                textBoxHastaBulgular.Clear();
                textBoxHastaTeshis.Clear();
                textBoxHastaTedavisi.Clear();
                MessageBox.Show("Hastaya yeni bir muayene başarılı bir şekilde eklenmiştir.", "MUAYENE EKLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                MuayeneListesi ML = new MuayeneListesi();
                ML.Show();
            }
        }

        private void btnMuayeneEkleIptal_Click(object sender, EventArgs e)
        {
            this.Hide();
            MuayeneListesi ML = new MuayeneListesi();
            ML.Show();
        }

        private void btnMuayeneEkleAnaSayfa_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
