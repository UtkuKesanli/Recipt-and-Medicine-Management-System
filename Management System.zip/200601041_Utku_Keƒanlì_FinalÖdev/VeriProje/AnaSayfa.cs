﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class AnaSayfa : Form
    {
        public AnaSayfa()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnHastaListe_Click(object sender, EventArgs e)
        {
            this.Hide();
            HastaListesi HL = new HastaListesi();
            HL.Show();
        }

        private void btnReceteListe_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReceteListesi RL = new ReceteListesi();
            RL.Show();
        }

        private void btnIlacListe_Click(object sender, EventArgs e)
        {
            this.Hide();
            IlacListesi IL = new IlacListesi();
            IL.Show();
        }

        private void btnMuayeneListe_Click(object sender, EventArgs e)
        {
            this.Hide();
            MuayeneListesi ML = new MuayeneListesi();
            ML.Show();
        }
    }
}
