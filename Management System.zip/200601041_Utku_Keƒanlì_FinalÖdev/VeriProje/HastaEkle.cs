﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class HastaEkle : Form
    {
        public HastaEkle()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        private void HastaEkle_Load(object sender, EventArgs e)
        {

        }

        private void btnHastaEkle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand HastaEkle = new NpgsqlCommand();
            HastaEkle.Connection = conn;
            HastaEkle.Parameters.AddWithValue("@HastaTC", Convert.ToDouble(textBoxHastaTC.Text));
            HastaEkle.Parameters.AddWithValue("@HastaIsim", textBoxHastaIsim.Text);
            HastaEkle.Parameters.AddWithValue("@HastaDogumYeri", textBoxHastaDogumYeri.Text);
            HastaEkle.Parameters.AddWithValue("@HastaAdresi", textBoxHastaAdresi.Text);
            HastaEkle.Parameters.AddWithValue("@HastaTelNO", textBoxHastaTelNO.Text);
            HastaEkle.Parameters.AddWithValue("@HastaMedeniDurum", textBoxHastaMedeniDurum.Text);
            HastaEkle.Parameters.AddWithValue("@HastaDogumGunu", Convert.ToDateTime(textBoxHastaDogumGunu.Text));
            HastaEkle.CommandType = CommandType.Text;
            HastaEkle.CommandText = "INSERT INTO public.\"Hastalar\"(\r\n\t\"HastaTCNo\", \"HastaIsim\", \"HastaDogumYeri\", \"HastaAdres\", \"HastaTelNo\", \"HastaMedeniDurum\", \"HastaDogumGunu\")\r\n\tVALUES (@HastaTC, @HastaIsim, @HastaDogumYeri, @HastaAdresi, @HastaTelNO, @HastaMedeniDurum, @HastaDogumGunu);";
            NpgsqlDataReader dr = HastaEkle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
            }

            HastaEkle.Dispose();
            conn.Close();
            textBoxHastaTC.Clear();
            textBoxHastaIsim.Clear();
            textBoxHastaDogumYeri.Clear();
            textBoxHastaAdresi.Clear();
            textBoxHastaTelNO.Clear();
            textBoxHastaMedeniDurum.Clear();
            textBoxHastaDogumGunu.Clear();
            MessageBox.Show("Yeni bir hasta başarılı bir şekilde eklenmiştir.", "HASTA EKLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Hide();
            HastaListesi HL = new HastaListesi();
            HL.Show();
        }

        private void btnHastaEkleIptal_Click(object sender, EventArgs e)
        {
            this.Hide();
            HastaListesi HL = new HastaListesi();
            HL.Show();
        }

        private void btnHastaEkleAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
