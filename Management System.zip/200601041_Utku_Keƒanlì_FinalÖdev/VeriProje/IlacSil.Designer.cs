﻿namespace VeriProje
{
    partial class IlacSil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIlacSilBul = new System.Windows.Forms.Button();
            this.dataGridViewIlacSil = new System.Windows.Forms.DataGridView();
            this.btnIlacSilAnaSayfa = new System.Windows.Forms.Button();
            this.btnIlacSilIptal = new System.Windows.Forms.Button();
            this.btnIlacSil = new System.Windows.Forms.Button();
            this.textBoxIlacSil = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIlacSil)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnIlacSilBul
            // 
            this.btnIlacSilBul.Location = new System.Drawing.Point(378, 123);
            this.btnIlacSilBul.Name = "btnIlacSilBul";
            this.btnIlacSilBul.Size = new System.Drawing.Size(91, 33);
            this.btnIlacSilBul.TabIndex = 21;
            this.btnIlacSilBul.Text = "İLACI BUL";
            this.btnIlacSilBul.UseVisualStyleBackColor = true;
            this.btnIlacSilBul.Click += new System.EventHandler(this.btnIlacSilBul_Click);
            // 
            // dataGridViewIlacSil
            // 
            this.dataGridViewIlacSil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIlacSil.Location = new System.Drawing.Point(85, 34);
            this.dataGridViewIlacSil.Name = "dataGridViewIlacSil";
            this.dataGridViewIlacSil.Size = new System.Drawing.Size(348, 69);
            this.dataGridViewIlacSil.TabIndex = 20;
            // 
            // btnIlacSilAnaSayfa
            // 
            this.btnIlacSilAnaSayfa.Location = new System.Drawing.Point(351, 169);
            this.btnIlacSilAnaSayfa.Name = "btnIlacSilAnaSayfa";
            this.btnIlacSilAnaSayfa.Size = new System.Drawing.Size(145, 62);
            this.btnIlacSilAnaSayfa.TabIndex = 18;
            this.btnIlacSilAnaSayfa.Text = "ANA SAYAFAYA DÖN";
            this.btnIlacSilAnaSayfa.UseVisualStyleBackColor = true;
            this.btnIlacSilAnaSayfa.Click += new System.EventHandler(this.btnIlacSilAnaSayfa_Click);
            // 
            // btnIlacSilIptal
            // 
            this.btnIlacSilIptal.Location = new System.Drawing.Point(188, 169);
            this.btnIlacSilIptal.Name = "btnIlacSilIptal";
            this.btnIlacSilIptal.Size = new System.Drawing.Size(145, 62);
            this.btnIlacSilIptal.TabIndex = 17;
            this.btnIlacSilIptal.Text = "İPTAL";
            this.btnIlacSilIptal.UseVisualStyleBackColor = true;
            this.btnIlacSilIptal.Click += new System.EventHandler(this.btnIlacSilIptal_Click);
            // 
            // btnIlacSil
            // 
            this.btnIlacSil.Location = new System.Drawing.Point(26, 169);
            this.btnIlacSil.Name = "btnIlacSil";
            this.btnIlacSil.Size = new System.Drawing.Size(145, 62);
            this.btnIlacSil.TabIndex = 16;
            this.btnIlacSil.Text = "İLACIN KAYDINI SİL";
            this.btnIlacSil.UseVisualStyleBackColor = true;
            this.btnIlacSil.Click += new System.EventHandler(this.btnIlacSil_Click);
            // 
            // textBoxIlacSil
            // 
            this.textBoxIlacSil.Location = new System.Drawing.Point(172, 130);
            this.textBoxIlacSil.Name = "textBoxIlacSil";
            this.textBoxIlacSil.Size = new System.Drawing.Size(182, 20);
            this.textBoxIlacSil.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "İlacın Barkod NO\'su";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnIlacSilAnaSayfa);
            this.groupBox1.Controls.Add(this.dataGridViewIlacSil);
            this.groupBox1.Controls.Add(this.btnIlacSilIptal);
            this.groupBox1.Controls.Add(this.btnIlacSilBul);
            this.groupBox1.Controls.Add(this.btnIlacSil);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBoxIlacSil);
            this.groupBox1.Location = new System.Drawing.Point(28, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(526, 269);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İLAÇ SİL";
            // 
            // IlacSil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(584, 333);
            this.Controls.Add(this.groupBox1);
            this.Name = "IlacSil";
            this.Text = "IlacSil";
            this.Load += new System.EventHandler(this.IlacSil_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIlacSil)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnIlacSilBul;
        private System.Windows.Forms.DataGridView dataGridViewIlacSil;
        private System.Windows.Forms.Button btnIlacSilAnaSayfa;
        private System.Windows.Forms.Button btnIlacSilIptal;
        private System.Windows.Forms.Button btnIlacSil;
        private System.Windows.Forms.TextBox textBoxIlacSil;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}