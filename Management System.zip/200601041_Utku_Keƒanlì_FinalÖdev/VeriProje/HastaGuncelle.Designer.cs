﻿namespace VeriProje
{
    partial class HastaGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHastaGuncelleAnaSayfa = new System.Windows.Forms.Button();
            this.btnHastaGuncelleIptal = new System.Windows.Forms.Button();
            this.textBoxHastaDogumGunu = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxHastaMedeniDurum = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxHastaTelNO = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxHastaAdresi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxHastaDogumYeri = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxHastaIsim = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxHastaTC = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHastaGuncelleBul = new System.Windows.Forms.Button();
            this.dataGridViewHastaGuncelle = new System.Windows.Forms.DataGridView();
            this.textBoxHastaGuncelle = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnHastaTCGuncelle = new System.Windows.Forms.Button();
            this.btnHastaIsimGuncelle = new System.Windows.Forms.Button();
            this.btnHastaDogumYeriGuncelle = new System.Windows.Forms.Button();
            this.btnHastaAdresGuncelle = new System.Windows.Forms.Button();
            this.btnHastaTelNOGuncelle = new System.Windows.Forms.Button();
            this.btnHastaMedeniDurumGuncelle = new System.Windows.Forms.Button();
            this.btnHastaDogumGunuGuncelle = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHastaGuncelle)).BeginInit();
            this.SuspendLayout();
            // 
            // btnHastaGuncelleAnaSayfa
            // 
            this.btnHastaGuncelleAnaSayfa.Location = new System.Drawing.Point(619, 342);
            this.btnHastaGuncelleAnaSayfa.Name = "btnHastaGuncelleAnaSayfa";
            this.btnHastaGuncelleAnaSayfa.Size = new System.Drawing.Size(145, 62);
            this.btnHastaGuncelleAnaSayfa.TabIndex = 33;
            this.btnHastaGuncelleAnaSayfa.Text = "ANA SAYFAYA DÖN";
            this.btnHastaGuncelleAnaSayfa.UseVisualStyleBackColor = true;
            this.btnHastaGuncelleAnaSayfa.Click += new System.EventHandler(this.btnHastaGuncelleAnaSayfa_Click);
            // 
            // btnHastaGuncelleIptal
            // 
            this.btnHastaGuncelleIptal.Location = new System.Drawing.Point(619, 268);
            this.btnHastaGuncelleIptal.Name = "btnHastaGuncelleIptal";
            this.btnHastaGuncelleIptal.Size = new System.Drawing.Size(145, 62);
            this.btnHastaGuncelleIptal.TabIndex = 32;
            this.btnHastaGuncelleIptal.Text = "İPTAL";
            this.btnHastaGuncelleIptal.UseVisualStyleBackColor = true;
            this.btnHastaGuncelleIptal.Click += new System.EventHandler(this.btnHastaGuncelleIptal_Click);
            // 
            // textBoxHastaDogumGunu
            // 
            this.textBoxHastaDogumGunu.Location = new System.Drawing.Point(261, 438);
            this.textBoxHastaDogumGunu.Name = "textBoxHastaDogumGunu";
            this.textBoxHastaDogumGunu.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaDogumGunu.TabIndex = 30;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(104, 438);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Hastanın Doğum Günü";
            // 
            // textBoxHastaMedeniDurum
            // 
            this.textBoxHastaMedeniDurum.Location = new System.Drawing.Point(261, 400);
            this.textBoxHastaMedeniDurum.Name = "textBoxHastaMedeniDurum";
            this.textBoxHastaMedeniDurum.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaMedeniDurum.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(104, 400);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "Hastanın Medeni Durumu";
            // 
            // textBoxHastaTelNO
            // 
            this.textBoxHastaTelNO.Location = new System.Drawing.Point(261, 363);
            this.textBoxHastaTelNO.Name = "textBoxHastaTelNO";
            this.textBoxHastaTelNO.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaTelNO.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(104, 363);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Hastanın Telefon Numarası";
            // 
            // textBoxHastaAdresi
            // 
            this.textBoxHastaAdresi.Location = new System.Drawing.Point(261, 326);
            this.textBoxHastaAdresi.Name = "textBoxHastaAdresi";
            this.textBoxHastaAdresi.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaAdresi.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(104, 326);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Hastanın Adresi";
            // 
            // textBoxHastaDogumYeri
            // 
            this.textBoxHastaDogumYeri.Location = new System.Drawing.Point(261, 290);
            this.textBoxHastaDogumYeri.Name = "textBoxHastaDogumYeri";
            this.textBoxHastaDogumYeri.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaDogumYeri.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(104, 290);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Hastanın Doğum Yeri";
            // 
            // textBoxHastaIsim
            // 
            this.textBoxHastaIsim.Location = new System.Drawing.Point(261, 253);
            this.textBoxHastaIsim.Name = "textBoxHastaIsim";
            this.textBoxHastaIsim.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaIsim.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(104, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Hastanın İsmi ve Soyismi";
            // 
            // textBoxHastaTC
            // 
            this.textBoxHastaTC.Location = new System.Drawing.Point(261, 218);
            this.textBoxHastaTC.Name = "textBoxHastaTC";
            this.textBoxHastaTC.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaTC.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Hastanın TC\'si";
            // 
            // btnHastaGuncelleBul
            // 
            this.btnHastaGuncelleBul.Location = new System.Drawing.Point(537, 154);
            this.btnHastaGuncelleBul.Name = "btnHastaGuncelleBul";
            this.btnHastaGuncelleBul.Size = new System.Drawing.Size(91, 33);
            this.btnHastaGuncelleBul.TabIndex = 37;
            this.btnHastaGuncelleBul.Text = "HASTAYI BUL";
            this.btnHastaGuncelleBul.UseVisualStyleBackColor = true;
            this.btnHastaGuncelleBul.Click += new System.EventHandler(this.btnHastaGuncelleBul_Click);
            // 
            // dataGridViewHastaGuncelle
            // 
            this.dataGridViewHastaGuncelle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHastaGuncelle.Location = new System.Drawing.Point(51, 59);
            this.dataGridViewHastaGuncelle.Name = "dataGridViewHastaGuncelle";
            this.dataGridViewHastaGuncelle.Size = new System.Drawing.Size(750, 69);
            this.dataGridViewHastaGuncelle.TabIndex = 36;
            // 
            // textBoxHastaGuncelle
            // 
            this.textBoxHastaGuncelle.Location = new System.Drawing.Point(324, 161);
            this.textBoxHastaGuncelle.Name = "textBoxHastaGuncelle";
            this.textBoxHastaGuncelle.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaGuncelle.TabIndex = 35;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(224, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 13);
            this.label8.TabIndex = 34;
            this.label8.Text = "Hastanın TC\'si";
            // 
            // btnHastaTCGuncelle
            // 
            this.btnHastaTCGuncelle.Location = new System.Drawing.Point(475, 214);
            this.btnHastaTCGuncelle.Name = "btnHastaTCGuncelle";
            this.btnHastaTCGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnHastaTCGuncelle.TabIndex = 38;
            this.btnHastaTCGuncelle.Text = "GÜNCELLE";
            this.btnHastaTCGuncelle.UseVisualStyleBackColor = true;
            this.btnHastaTCGuncelle.Click += new System.EventHandler(this.btnHastaTCGuncelle_Click);
            // 
            // btnHastaIsimGuncelle
            // 
            this.btnHastaIsimGuncelle.Location = new System.Drawing.Point(475, 249);
            this.btnHastaIsimGuncelle.Name = "btnHastaIsimGuncelle";
            this.btnHastaIsimGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnHastaIsimGuncelle.TabIndex = 39;
            this.btnHastaIsimGuncelle.Text = "GÜNCELLE";
            this.btnHastaIsimGuncelle.UseVisualStyleBackColor = true;
            this.btnHastaIsimGuncelle.Click += new System.EventHandler(this.btnHastaIsimGuncelle_Click);
            // 
            // btnHastaDogumYeriGuncelle
            // 
            this.btnHastaDogumYeriGuncelle.Location = new System.Drawing.Point(475, 286);
            this.btnHastaDogumYeriGuncelle.Name = "btnHastaDogumYeriGuncelle";
            this.btnHastaDogumYeriGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnHastaDogumYeriGuncelle.TabIndex = 40;
            this.btnHastaDogumYeriGuncelle.Text = "GÜNCELLE";
            this.btnHastaDogumYeriGuncelle.UseVisualStyleBackColor = true;
            this.btnHastaDogumYeriGuncelle.Click += new System.EventHandler(this.btnHastaDogumYeriGuncelle_Click);
            // 
            // btnHastaAdresGuncelle
            // 
            this.btnHastaAdresGuncelle.Location = new System.Drawing.Point(475, 322);
            this.btnHastaAdresGuncelle.Name = "btnHastaAdresGuncelle";
            this.btnHastaAdresGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnHastaAdresGuncelle.TabIndex = 41;
            this.btnHastaAdresGuncelle.Text = "GÜNCELLE";
            this.btnHastaAdresGuncelle.UseVisualStyleBackColor = true;
            this.btnHastaAdresGuncelle.Click += new System.EventHandler(this.btnHastaAdresGuncelle_Click);
            // 
            // btnHastaTelNOGuncelle
            // 
            this.btnHastaTelNOGuncelle.Location = new System.Drawing.Point(475, 359);
            this.btnHastaTelNOGuncelle.Name = "btnHastaTelNOGuncelle";
            this.btnHastaTelNOGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnHastaTelNOGuncelle.TabIndex = 42;
            this.btnHastaTelNOGuncelle.Text = "GÜNCELLE";
            this.btnHastaTelNOGuncelle.UseVisualStyleBackColor = true;
            this.btnHastaTelNOGuncelle.Click += new System.EventHandler(this.btnHastaTelNOGuncelle_Click);
            // 
            // btnHastaMedeniDurumGuncelle
            // 
            this.btnHastaMedeniDurumGuncelle.Location = new System.Drawing.Point(475, 396);
            this.btnHastaMedeniDurumGuncelle.Name = "btnHastaMedeniDurumGuncelle";
            this.btnHastaMedeniDurumGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnHastaMedeniDurumGuncelle.TabIndex = 43;
            this.btnHastaMedeniDurumGuncelle.Text = "GÜNCELLE";
            this.btnHastaMedeniDurumGuncelle.UseVisualStyleBackColor = true;
            this.btnHastaMedeniDurumGuncelle.Click += new System.EventHandler(this.btnHastaMedeniDurumGuncelle_Click);
            // 
            // btnHastaDogumGunuGuncelle
            // 
            this.btnHastaDogumGunuGuncelle.Location = new System.Drawing.Point(475, 434);
            this.btnHastaDogumGunuGuncelle.Name = "btnHastaDogumGunuGuncelle";
            this.btnHastaDogumGunuGuncelle.Size = new System.Drawing.Size(91, 27);
            this.btnHastaDogumGunuGuncelle.TabIndex = 44;
            this.btnHastaDogumGunuGuncelle.Text = "GÜNCELLE";
            this.btnHastaDogumGunuGuncelle.UseVisualStyleBackColor = true;
            this.btnHastaDogumGunuGuncelle.Click += new System.EventHandler(this.btnHastaDogumGunuGuncelle_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(31, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(792, 459);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "HASTA GÜNCELLE";
            // 
            // HastaGuncelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(859, 514);
            this.Controls.Add(this.btnHastaDogumGunuGuncelle);
            this.Controls.Add(this.btnHastaMedeniDurumGuncelle);
            this.Controls.Add(this.btnHastaTelNOGuncelle);
            this.Controls.Add(this.btnHastaAdresGuncelle);
            this.Controls.Add(this.btnHastaDogumYeriGuncelle);
            this.Controls.Add(this.btnHastaIsimGuncelle);
            this.Controls.Add(this.btnHastaTCGuncelle);
            this.Controls.Add(this.btnHastaGuncelleBul);
            this.Controls.Add(this.dataGridViewHastaGuncelle);
            this.Controls.Add(this.textBoxHastaGuncelle);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnHastaGuncelleAnaSayfa);
            this.Controls.Add(this.btnHastaGuncelleIptal);
            this.Controls.Add(this.textBoxHastaDogumGunu);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxHastaMedeniDurum);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxHastaTelNO);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxHastaAdresi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxHastaDogumYeri);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxHastaIsim);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxHastaTC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "HastaGuncelle";
            this.Text = "HastaGuncelle";
            this.Load += new System.EventHandler(this.HastaGuncelle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHastaGuncelle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHastaGuncelleAnaSayfa;
        private System.Windows.Forms.Button btnHastaGuncelleIptal;
        private System.Windows.Forms.TextBox textBoxHastaDogumGunu;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxHastaMedeniDurum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxHastaTelNO;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxHastaAdresi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxHastaDogumYeri;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxHastaIsim;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxHastaTC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnHastaGuncelleBul;
        private System.Windows.Forms.DataGridView dataGridViewHastaGuncelle;
        private System.Windows.Forms.TextBox textBoxHastaGuncelle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnHastaTCGuncelle;
        private System.Windows.Forms.Button btnHastaIsimGuncelle;
        private System.Windows.Forms.Button btnHastaDogumYeriGuncelle;
        private System.Windows.Forms.Button btnHastaAdresGuncelle;
        private System.Windows.Forms.Button btnHastaTelNOGuncelle;
        private System.Windows.Forms.Button btnHastaMedeniDurumGuncelle;
        private System.Windows.Forms.Button btnHastaDogumGunuGuncelle;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}