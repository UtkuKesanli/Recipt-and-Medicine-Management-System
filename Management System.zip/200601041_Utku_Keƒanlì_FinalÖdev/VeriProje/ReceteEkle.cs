﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class ReceteEkle : Form
    {
        public ReceteEkle()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        private void ReceteEkle_Load(object sender, EventArgs e)
        {

        }

        private void btnReceteEkleAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }

        private void btnReceteEkleIptal_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReceteListesi RL = new ReceteListesi();
            RL.Show();
        }

        private void btnHastaReceteBul_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand ReceteEkle = new NpgsqlCommand();
            ReceteEkle.Connection = conn;
            ReceteEkle.Parameters.AddWithValue("@HastaTCNo", Convert.ToDouble(textBoxReceteBul.Text));
            ReceteEkle.CommandType = CommandType.Text;
            ReceteEkle.CommandText = "SELECT * FROM \"Hastalar\" WHERE \"HastaTCNo\" = @HastaTCNo";
            NpgsqlDataReader dr = ReceteEkle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewReceteEkle.DataSource = dt;
            }

            ReceteEkle.Dispose();
            conn.Close();
        }

        private void btnYeniReceteEkle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand ReceteEkle = new NpgsqlCommand();
            ReceteEkle.Connection = conn;
            ReceteEkle.Parameters.AddWithValue("@HastaTCNo", Convert.ToDouble(textBoxReceteBul.Text));
            ReceteEkle.Parameters.AddWithValue("@MuayeneTarihi", Convert.ToDateTime(textBoxMuayeneTarihi.Text));
            ReceteEkle.Parameters.AddWithValue("@HastaSikayet", textBoxHastaSikayet.Text);
            ReceteEkle.Parameters.AddWithValue("@HastaTani", textBoxHastaTani.Text);
            ReceteEkle.Parameters.AddWithValue("@HastaTedavi", textBoxHastaTedavi.Text);
            ReceteEkle.Parameters.AddWithValue("@HastaReceteNo", textBoxHastaReceteNo.Text.ToUpper());
            ReceteEkle.CommandType = CommandType.Text;
            ReceteEkle.CommandText = "INSERT INTO public.\"Receteler\"(\r\n\t\"HastaTCNo\", \"MuayeneTarihi\", \"HastaSikayet\", \"HastaTani\", \"HastaTedavi\", \"HastaReceteNo\")\r\n\tVALUES (@HastaTCNo, @MuayeneTarihi, @HastaSikayet, @HastaTani, @HastaTedavi, @HastaReceteNo);";
            ReceteEkle.CommandText = "UPDATE \"Muayeneler\" SET \"MuayeneTarihi\" = @MuayeneTarihi, \"HastaTedavi\" = @MHastaTedavi WHERE \"HastaTCNo\" = @HastaTCNo";
            NpgsqlDataReader dr = ReceteEkle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
            }

            ReceteEkle.Dispose();
            conn.Close();
            textBoxMuayeneTarihi.Clear();
            textBoxHastaSikayet.Clear();
            textBoxHastaTani.Clear();
            textBoxHastaTedavi.Clear();
            textBoxHastaReceteNo.Clear();
            MessageBox.Show("Hastaya yeni bir reçete başarılı bir şekilde eklenmiştir.", "REÇETE EKLENDİ", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Hide();
            ReceteListesi RL = new ReceteListesi();
            RL.Show();
        }

        private void btnReceteEkleVerGuncelle_Click(object sender, EventArgs e)
        {
            conn.Open();
            NpgsqlCommand ReceteEkle = new NpgsqlCommand();
            ReceteEkle.Connection = conn;
            ReceteEkle.Parameters.AddWithValue("@HastaTCNo", Convert.ToDouble(textBoxReceteBul.Text));
            ReceteEkle.CommandType = CommandType.Text;
            ReceteEkle.CommandText = "SELECT * FROM \"Receteler\" WHERE \"HastaTCNo\" = @HastaTCNo";
            NpgsqlDataReader dr = ReceteEkle.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewReceteEkle.DataSource = dt;
            }

            ReceteEkle.Dispose();
            conn.Close();
        }
    }
}
