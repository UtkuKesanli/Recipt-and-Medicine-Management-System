﻿namespace VeriProje
{
    partial class MuayeneEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHastaMuayeneBul = new System.Windows.Forms.Button();
            this.btnYeniMuayeneEkle = new System.Windows.Forms.Button();
            this.textBoxMuayeneBul = new System.Windows.Forms.TextBox();
            this.textBoxHastaIsim = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnMuayeneEkleIptal = new System.Windows.Forms.Button();
            this.btnMuayeneEkleAnaSayfa = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxHastaBulgular = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxHastaDogumTarihi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxHastaTeshis = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxMuayeneTarihi = new System.Windows.Forms.TextBox();
            this.textBoxHastaTedavisi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewMuayeneEkle = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMuayeneEkle)).BeginInit();
            this.SuspendLayout();
            // 
            // btnHastaMuayeneBul
            // 
            this.btnHastaMuayeneBul.Location = new System.Drawing.Point(546, 144);
            this.btnHastaMuayeneBul.Name = "btnHastaMuayeneBul";
            this.btnHastaMuayeneBul.Size = new System.Drawing.Size(91, 33);
            this.btnHastaMuayeneBul.TabIndex = 83;
            this.btnHastaMuayeneBul.Text = "HASTAYI BUL";
            this.btnHastaMuayeneBul.UseVisualStyleBackColor = true;
            this.btnHastaMuayeneBul.Click += new System.EventHandler(this.btnHastaMuayeneBul_Click);
            // 
            // btnYeniMuayeneEkle
            // 
            this.btnYeniMuayeneEkle.Location = new System.Drawing.Point(558, 219);
            this.btnYeniMuayeneEkle.Name = "btnYeniMuayeneEkle";
            this.btnYeniMuayeneEkle.Size = new System.Drawing.Size(147, 61);
            this.btnYeniMuayeneEkle.TabIndex = 84;
            this.btnYeniMuayeneEkle.Text = "YENİ BİR MUAYENE EKLE";
            this.btnYeniMuayeneEkle.UseVisualStyleBackColor = true;
            this.btnYeniMuayeneEkle.Click += new System.EventHandler(this.btnYeniMuayeneEkle_Click);
            // 
            // textBoxMuayeneBul
            // 
            this.textBoxMuayeneBul.Location = new System.Drawing.Point(339, 151);
            this.textBoxMuayeneBul.Name = "textBoxMuayeneBul";
            this.textBoxMuayeneBul.Size = new System.Drawing.Size(182, 20);
            this.textBoxMuayeneBul.TabIndex = 81;
            // 
            // textBoxHastaIsim
            // 
            this.textBoxHastaIsim.Location = new System.Drawing.Point(310, 240);
            this.textBoxHastaIsim.Name = "textBoxHastaIsim";
            this.textBoxHastaIsim.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaIsim.TabIndex = 71;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(240, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 13);
            this.label8.TabIndex = 80;
            this.label8.Text = "Hastanın TC\'si";
            // 
            // btnMuayeneEkleIptal
            // 
            this.btnMuayeneEkleIptal.Location = new System.Drawing.Point(558, 295);
            this.btnMuayeneEkleIptal.Name = "btnMuayeneEkleIptal";
            this.btnMuayeneEkleIptal.Size = new System.Drawing.Size(147, 56);
            this.btnMuayeneEkleIptal.TabIndex = 78;
            this.btnMuayeneEkleIptal.Text = "İPTAL";
            this.btnMuayeneEkleIptal.UseVisualStyleBackColor = true;
            this.btnMuayeneEkleIptal.Click += new System.EventHandler(this.btnMuayeneEkleIptal_Click);
            // 
            // btnMuayeneEkleAnaSayfa
            // 
            this.btnMuayeneEkleAnaSayfa.Location = new System.Drawing.Point(558, 370);
            this.btnMuayeneEkleAnaSayfa.Name = "btnMuayeneEkleAnaSayfa";
            this.btnMuayeneEkleAnaSayfa.Size = new System.Drawing.Size(147, 57);
            this.btnMuayeneEkleAnaSayfa.TabIndex = 79;
            this.btnMuayeneEkleAnaSayfa.Text = "ANA SAYFAYA DÖN";
            this.btnMuayeneEkleAnaSayfa.UseVisualStyleBackColor = true;
            this.btnMuayeneEkleAnaSayfa.Click += new System.EventHandler(this.btnMuayeneEkleAnaSayfa_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(132, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 70;
            this.label3.Text = "Hastanın İsmi";
            // 
            // textBoxHastaBulgular
            // 
            this.textBoxHastaBulgular.Location = new System.Drawing.Point(310, 324);
            this.textBoxHastaBulgular.Name = "textBoxHastaBulgular";
            this.textBoxHastaBulgular.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaBulgular.TabIndex = 77;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(132, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 68;
            this.label2.Text = "Hastanın Muayene Tarihi";
            // 
            // textBoxHastaDogumTarihi
            // 
            this.textBoxHastaDogumTarihi.Location = new System.Drawing.Point(310, 282);
            this.textBoxHastaDogumTarihi.Name = "textBoxHastaDogumTarihi";
            this.textBoxHastaDogumTarihi.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaDogumTarihi.TabIndex = 75;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(132, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 72;
            this.label4.Text = "Hastanın Teşhisi";
            // 
            // textBoxHastaTeshis
            // 
            this.textBoxHastaTeshis.Location = new System.Drawing.Point(310, 367);
            this.textBoxHastaTeshis.Name = "textBoxHastaTeshis";
            this.textBoxHastaTeshis.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaTeshis.TabIndex = 73;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(132, 327);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 13);
            this.label6.TabIndex = 76;
            this.label6.Text = "Hastanın Bulguları";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(132, 285);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 74;
            this.label5.Text = "Hastanın Doğum Tarihi";
            // 
            // textBoxMuayeneTarihi
            // 
            this.textBoxMuayeneTarihi.Location = new System.Drawing.Point(310, 200);
            this.textBoxMuayeneTarihi.Name = "textBoxMuayeneTarihi";
            this.textBoxMuayeneTarihi.Size = new System.Drawing.Size(182, 20);
            this.textBoxMuayeneTarihi.TabIndex = 69;
            // 
            // textBoxHastaTedavisi
            // 
            this.textBoxHastaTedavisi.Location = new System.Drawing.Point(310, 410);
            this.textBoxHastaTedavisi.Name = "textBoxHastaTedavisi";
            this.textBoxHastaTedavisi.Size = new System.Drawing.Size(182, 20);
            this.textBoxHastaTedavisi.TabIndex = 87;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(132, 410);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 86;
            this.label1.Text = "Hastanın Tedavisi";
            // 
            // dataGridViewMuayeneEkle
            // 
            this.dataGridViewMuayeneEkle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMuayeneEkle.Location = new System.Drawing.Point(48, 54);
            this.dataGridViewMuayeneEkle.Name = "dataGridViewMuayeneEkle";
            this.dataGridViewMuayeneEkle.Size = new System.Drawing.Size(750, 69);
            this.dataGridViewMuayeneEkle.TabIndex = 88;
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(24, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(801, 436);
            this.groupBox1.TabIndex = 89;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MUAYENE EKLE";
            // 
            // MuayeneEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(857, 488);
            this.Controls.Add(this.dataGridViewMuayeneEkle);
            this.Controls.Add(this.textBoxHastaTedavisi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnHastaMuayeneBul);
            this.Controls.Add(this.btnYeniMuayeneEkle);
            this.Controls.Add(this.textBoxMuayeneBul);
            this.Controls.Add(this.textBoxHastaIsim);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnMuayeneEkleIptal);
            this.Controls.Add(this.btnMuayeneEkleAnaSayfa);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxHastaBulgular);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxHastaDogumTarihi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxHastaTeshis);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxMuayeneTarihi);
            this.Controls.Add(this.groupBox1);
            this.Name = "MuayeneEkle";
            this.Text = "MuayeneEkle";
            this.Load += new System.EventHandler(this.MuayeneEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMuayeneEkle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnHastaMuayeneBul;
        private System.Windows.Forms.Button btnYeniMuayeneEkle;
        private System.Windows.Forms.TextBox textBoxMuayeneBul;
        private System.Windows.Forms.TextBox textBoxHastaIsim;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnMuayeneEkleIptal;
        private System.Windows.Forms.Button btnMuayeneEkleAnaSayfa;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxHastaBulgular;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxHastaDogumTarihi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxHastaTeshis;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxMuayeneTarihi;
        private System.Windows.Forms.TextBox textBoxHastaTedavisi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewMuayeneEkle;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}