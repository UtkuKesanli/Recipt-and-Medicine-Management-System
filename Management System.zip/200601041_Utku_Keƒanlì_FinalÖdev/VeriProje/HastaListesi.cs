﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Windows.Forms;

namespace VeriProje
{
    public partial class HastaListesi : Form
    {
        public HastaListesi()
        {
            InitializeComponent();
        }

        NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=MuayeneBilgiYonetimSistemi; User Id=postgres; Password=utku");

        public void VerileriGoster()
        {
            conn.Open();
            NpgsqlCommand veriler = new NpgsqlCommand();
            veriler.Connection = conn;
            veriler.CommandType = CommandType.Text;
            veriler.CommandText = "SELECT * FROM Public.\"Hastalar\"";
            NpgsqlDataReader dr = veriler.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridViewHastaListesi.DataSource = dt;
            }

            veriler.Dispose();
            conn.Close();
        }

        private void HastaListesi_Load(object sender, EventArgs e)
        {
            VerileriGoster();
        }

        private void btnYeniHastaEkle_Click(object sender, EventArgs e)
        {
            this.Hide();
            HastaEkle HE = new HastaEkle();
            HE.Show();
        }

        private void btnBirHastaSil_Click(object sender, EventArgs e)
        {
            this.Hide();
            HastaSil HS = new HastaSil();
            HS.Show();
        }

        private void btnBirHastaGuncelle_Click(object sender, EventArgs e)
        {
            this.Hide();
            HastaGuncelle HG = new HastaGuncelle();
            HG.Show();
        }

        private void btnHaslaListeAnaSayfa_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa AS = new AnaSayfa();
            AS.Show();
        }
    }
}
