﻿namespace VeriProje
{
    partial class IlacListesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnHaslaIlacAnaSayfa = new System.Windows.Forms.Button();
            this.btnBirIlacGuncelle = new System.Windows.Forms.Button();
            this.btnBirIlacSil = new System.Windows.Forms.Button();
            this.btnYeniIlacEkle = new System.Windows.Forms.Button();
            this.dataGridViewIlacListesi = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIlacListesi)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnHaslaIlacAnaSayfa);
            this.groupBox1.Controls.Add(this.btnBirIlacGuncelle);
            this.groupBox1.Controls.Add(this.btnBirIlacSil);
            this.groupBox1.Controls.Add(this.btnYeniIlacEkle);
            this.groupBox1.Controls.Add(this.dataGridViewIlacListesi);
            this.groupBox1.Location = new System.Drawing.Point(24, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(577, 362);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İLAÇLARIN LİSTESİ";
            // 
            // btnHaslaIlacAnaSayfa
            // 
            this.btnHaslaIlacAnaSayfa.Location = new System.Drawing.Point(402, 266);
            this.btnHaslaIlacAnaSayfa.Name = "btnHaslaIlacAnaSayfa";
            this.btnHaslaIlacAnaSayfa.Size = new System.Drawing.Size(145, 62);
            this.btnHaslaIlacAnaSayfa.TabIndex = 7;
            this.btnHaslaIlacAnaSayfa.Text = "ANA SAYAFAYA DÖN";
            this.btnHaslaIlacAnaSayfa.UseVisualStyleBackColor = true;
            this.btnHaslaIlacAnaSayfa.Click += new System.EventHandler(this.btnHaslaIlacAnaSayfa_Click);
            // 
            // btnBirIlacGuncelle
            // 
            this.btnBirIlacGuncelle.Location = new System.Drawing.Point(402, 188);
            this.btnBirIlacGuncelle.Name = "btnBirIlacGuncelle";
            this.btnBirIlacGuncelle.Size = new System.Drawing.Size(145, 62);
            this.btnBirIlacGuncelle.TabIndex = 6;
            this.btnBirIlacGuncelle.Text = "BİR İLAÇ KAYDINI GÜNCELLE";
            this.btnBirIlacGuncelle.UseVisualStyleBackColor = true;
            this.btnBirIlacGuncelle.Click += new System.EventHandler(this.btnBirIlacGuncelle_Click);
            // 
            // btnBirIlacSil
            // 
            this.btnBirIlacSil.Location = new System.Drawing.Point(402, 109);
            this.btnBirIlacSil.Name = "btnBirIlacSil";
            this.btnBirIlacSil.Size = new System.Drawing.Size(145, 62);
            this.btnBirIlacSil.TabIndex = 5;
            this.btnBirIlacSil.Text = "BİR İLAÇ KAYDINI SİL";
            this.btnBirIlacSil.UseVisualStyleBackColor = true;
            this.btnBirIlacSil.Click += new System.EventHandler(this.btnBirIlacSil_Click);
            // 
            // btnYeniIlacEkle
            // 
            this.btnYeniIlacEkle.Location = new System.Drawing.Point(402, 32);
            this.btnYeniIlacEkle.Name = "btnYeniIlacEkle";
            this.btnYeniIlacEkle.Size = new System.Drawing.Size(145, 62);
            this.btnYeniIlacEkle.TabIndex = 4;
            this.btnYeniIlacEkle.Text = "YENİ BİR İLAÇ EKLE";
            this.btnYeniIlacEkle.UseVisualStyleBackColor = true;
            this.btnYeniIlacEkle.Click += new System.EventHandler(this.btnYeniIlacEkle_Click);
            // 
            // dataGridViewIlacListesi
            // 
            this.dataGridViewIlacListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIlacListesi.Location = new System.Drawing.Point(28, 32);
            this.dataGridViewIlacListesi.Name = "dataGridViewIlacListesi";
            this.dataGridViewIlacListesi.Size = new System.Drawing.Size(341, 296);
            this.dataGridViewIlacListesi.TabIndex = 0;
            // 
            // IlacListesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(629, 415);
            this.Controls.Add(this.groupBox1);
            this.Name = "IlacListesi";
            this.Text = "IlacListesi";
            this.Load += new System.EventHandler(this.IlacListesi_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIlacListesi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnHaslaIlacAnaSayfa;
        private System.Windows.Forms.Button btnBirIlacGuncelle;
        private System.Windows.Forms.Button btnBirIlacSil;
        private System.Windows.Forms.Button btnYeniIlacEkle;
        private System.Windows.Forms.DataGridView dataGridViewIlacListesi;
    }
}